import { Injectable, Logger } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Position, PositionDocument } from "./schema/position.schema";
import { Model } from "mongoose";
import { ClosePositionDTO, CloseTradeDTO, CreatePositionDTO, CreateTradeDTO, PositionDTO, UpdatePositionTargetsDTO } from "@project-zero/models";
import { RpcException } from "@nestjs/microservices";

@Injectable()
export class PositionService {
  private readonly _logger = new Logger(PositionService.name);

  constructor(@InjectModel(Position.name) private readonly _positionModel: Model<PositionDocument>) {}

  async createPosition(createPositionDTO: CreatePositionDTO, createTradeDTOs: CreateTradeDTO[]): Promise<void> {
    try {
      // save lab element and lab tests in db
      await this._positionModel.create({ ...createPositionDTO, trades: createTradeDTOs});
    } catch(err) {
      this._logger.error('createPosition(): ' + err.message);
      throw new RpcException(err.message);
    }
  }

  /* ------------- TODO -------------- */
  /* async getPositionsBySearch(): Promise<PositionDTO[]> {
    // find all lab elements in db
    const labElementDocs = await this._labElementModel.find().exec();

    // throw and log error if not found
    if (!labElementDocs || labElementDocs.length === 0) {
      const msg = `No lab elements found`;
      this._logger.error('getLabElements(): ' + msg)
      throw new RpcException(msg);
    }

    // return lab elements
    return labElementDocs;
  } */

  async getPositionById(id: string): Promise<PositionDTO> {
    // find position in db
    const positionDoc = await this._positionModel.findById(id).exec();

    // throw and log error if not found
    if (!positionDoc) {
      const msg = `Position #${id} not found`;
      this._logger.error('getPositionById(): ' + msg)
      throw new RpcException(msg);
    }

    return positionDoc;
  }

  async getOpenPositionByEpic(epic: string): Promise<PositionDTO> {
    // find position in db
    const positionDoc = await this._positionModel.findOne({ 'isOpen': true, 'trades.epic': epic })

    // throw and log error if not found
    if (!positionDoc) {
      const msg = `Position with epic: ${epic} not found`;
      this._logger.error('getPositionByEpic(): ' + msg)
      throw new RpcException(msg);
    }

    return positionDoc;
  }

  async updatePositionTargets(updatePositionTargetsDTO: UpdatePositionTargetsDTO): Promise<void> {
    // find by id and update
    await this._positionModel.findByIdAndUpdate(updatePositionTargetsDTO._id, updatePositionTargetsDTO);
  }

  async closePosition(closePositionDTO: ClosePositionDTO, closeTradeDTOs: CloseTradeDTO[]): Promise<void> {
    // update all trades
    for (let i = 0; i < closeTradeDTOs.length; i++) {
      await this._positionModel.findOneAndUpdate(
        { 'trades._id': closeTradeDTOs[i]._id},
        { $set: { 'trades.$': { ...closeTradeDTOs[i] }}}
      );
    }

    // find by id and update
    const updatedPositionDoc = await this._positionModel.findByIdAndUpdate(
      closePositionDTO._id,
      closePositionDTO,
      { new: true }
    );

    // throw and log error if not found
    if (!updatedPositionDoc) {
      const msg = `Position #${closePositionDTO._id} not found`;
      this._logger.error('closePosition(): ' + msg)
      throw new RpcException(msg);
    }
  }

  async deletePositionsRelatedToTest(testId: string): Promise<number> {
    // delete all positions related to testId
    const numDeletesPositions = (await this._positionModel.deleteMany({ testId })).deletedCount;

    return numDeletesPositions;
  }

  async deleteOpenPositionsRelatedToTest(testId: string): Promise<number> {
    // delete all positions related to testId
    const numDeletesPositions = (await this._positionModel.deleteMany({ testId, isOpen: true })).deletedCount;

    return numDeletesPositions;
  }
}
