import { Global, Module } from "@nestjs/common";
import { ExchangeStreamingController } from "./exchange-streaming.controller";
import { ExchangeStreamingService } from "./exchange-streaming.service";
import { MongooseModule } from "@nestjs/mongoose";
import { BackTestSnapshot, BackTestSnapshotSchema } from "./schema/back-test-snakshot.schema";
import { MessageBrokerEnv } from "@project-zero/models";

@Global()
@Module({
  imports: [MongooseModule.forFeature([{ name: BackTestSnapshot.name, schema: BackTestSnapshotSchema }], MessageBrokerEnv.DEMO)],
  controllers: [ExchangeStreamingController],
  providers: [ExchangeStreamingService]
})
export class ExchangeStreamingModule {}
