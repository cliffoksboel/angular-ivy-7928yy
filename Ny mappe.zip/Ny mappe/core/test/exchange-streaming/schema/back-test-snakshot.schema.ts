import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { HydratedDocument } from "mongoose";
import { Transform } from 'class-transformer';

export type BackTestSnapshotDocument = HydratedDocument<BackTestSnapshot>;

@Schema()
export class BackTestSnapshot {
  @Transform(({ value }) => value.toString())
  _id: string;

  @Prop({required: true})
  epic: string;

  @Prop({required: true})
  timestamp: number;

  @Prop({required: true})
  open: number;

  @Prop({required: true})
  high: number;

  @Prop({required: true})
  low: number;

  @Prop({required: true})
  close: number;

  @Prop({required: true})
  volume: number;
}

export const BackTestSnapshotSchema = SchemaFactory.createForClass(BackTestSnapshot);
