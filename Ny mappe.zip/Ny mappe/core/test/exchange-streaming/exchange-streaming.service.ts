import { Injectable } from "@nestjs/common";
import { SnapshotService } from "../../snapshot/snapshot.service";
import { MarketStatus, NewPositionStreamDataDTO, NewSnapshotStreamDataDTO } from "@project-zero/models";
import { CacheService, QueueService } from "../../shared";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { BackTestSnapshot, BackTestSnapshotDocument } from "./schema/back-test-snakshot.schema";

@Injectable()
export class ExchangeStreamingService {
  private _initialTimestamp = 0;
  private _prevTimestamp: number;
  private _currentSnapshot: NewSnapshotStreamDataDTO[] = [];

  get currentSnapshot(): NewSnapshotStreamDataDTO[] {
    return this._currentSnapshot;
  }

  constructor(
    @InjectModel(BackTestSnapshot.name) private readonly _snapshotModel: Model<BackTestSnapshotDocument>,
    private readonly _snapshotService: SnapshotService,
    private readonly _cacheService: CacheService,
    private readonly _queueService: QueueService
  ) {}

  async startStreamingSnapshots(): Promise<void> {
    // get first snapshots from db
    const snapshotDocs = await this._snapshotModel.find({ timestamp: this._initialTimestamp });

    // generate snapshot stream data
    const newSnapshots = this.createSnapshotStreamData(snapshotDocs);

    // send snapshots to controller
    this._snapshotService.handleNewSnapshotFromExchange(newSnapshots);

    // update prev timestamp and current snapshot
    this._prevTimestamp = this._initialTimestamp;
    this._currentSnapshot = newSnapshots;
  }

  async sendNextBackTestSnapshots(): Promise<void> {
    // get next snapshots (looking at timestamp) from db
    const snapshotDocs = await this._snapshotModel.find({ timestamp: this._prevTimestamp + 1 });

    // get open positions
    const openPositions = await this._cacheService.getAllOpenPositions();

    // generate snapshot stream data
    const newSnapshots = this.createSnapshotStreamData(snapshotDocs);

    // send position stream data to queue if position is being streamed (looking at epics)
    for (let i = 0; i < openPositions.length; i++) {
      // generate position stream data
      const newMarketData = this.createPositionStreamData(openPositions[i].trades[0].epic, newSnapshots);

      // send to queue
      await this._queueService.analyzePositionData(newMarketData);
    }

    // send snapshots to controller
    this._snapshotService.handleNewSnapshotFromExchange(newSnapshots);

    // update prev timestamp and current snapshot
    this._prevTimestamp = this._prevTimestamp + 1;
    this._currentSnapshot = newSnapshots;
  }

  /************
  ** HELPERS **
  ************/

  private createSnapshotStreamData(snapshotDocs: BackTestSnapshot[]): NewSnapshotStreamDataDTO[] {
    const newSnapshots: NewSnapshotStreamDataDTO[] = [];

    // get spread from settings
    // --------------- MISSING --------------
    const spread = 1;

    // iterate snapshot docs
    snapshotDocs.forEach(snapshot => {
      // push objects to array
      newSnapshots.push({
        epic: snapshot.epic,
        timestamp: snapshot.timestamp,
        volume: snapshot.volume,
        offerOpen: snapshot.open + spread / 2,
        offerHigh: snapshot.high + spread / 2,
        offerLow: snapshot.low + spread / 2,
        offerClose: snapshot.close + spread / 2,
        bidOpen: snapshot.open - spread / 2,
        bidHigh: snapshot.high - spread / 2,
        bidLow: snapshot.low - spread / 2,
        bidClose: snapshot.close - spread / 2
      })
    });

    return newSnapshots
  }

  createPositionStreamData(epic: string, newSnapshots: NewSnapshotStreamDataDTO[]): NewPositionStreamDataDTO {
    // find snapshotDoc
    const snapshot = newSnapshots.find(snapshot => snapshot.epic === epic);

    return {
      epic,
      marketState: MarketStatus.TRADEABLE,
      bid: snapshot.bidClose,
      offer: snapshot.offerClose
    }
  }
}
