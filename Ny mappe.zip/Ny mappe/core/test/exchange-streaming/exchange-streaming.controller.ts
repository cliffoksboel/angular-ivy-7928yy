import { Controller } from "@nestjs/common";
import { ExchangeStreamingService } from "./exchange-streaming.service";
import { EventPattern } from "@nestjs/microservices";
import { MessageBrokerEnv, MessageBrokerEvent } from "@project-zero/models";

@Controller()
export class ExchangeStreamingController {
  constructor(private readonly _exchangeStreamingService: ExchangeStreamingService) {}

  @EventPattern({ event: MessageBrokerEvent.START_STREAMING_BACK_TEST_SNAPSHOTS, podEnv: MessageBrokerEnv.DEMO })
  async startStreamingBackTestSnapshots(): Promise<void> {
    await this._exchangeStreamingService.startStreamingSnapshots();
  }

  @EventPattern({ event: MessageBrokerEvent.SEND_NEXT_BACK_TEST_SNAPSHOTS, podEnv: MessageBrokerEnv.DEMO })
  async sendNextBackTestSnapshots(): Promise<void> {
    await this._exchangeStreamingService.sendNextBackTestSnapshots();
  }
}
