import { MarketTreeDTO } from "@project-zero/models";

export const BACK_TEST_MARKET_TREE: MarketTreeDTO = {
  _id: 'back-test-market-tree',
  timestamp: Date.now(),
  selectedMarkets: ['Forex'],
  instruments: [
    {
      name: 'AUD/CAD_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Australasian',
      epics: [{ epic: 'CS.D.AUDCAD.MINI.IP' }]
    },
    {
      name: 'AUD/CHF_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Australasian',
      epics: [{ epic: 'CS.D.AUDCHF.MINI.IP' }]
    },
    {
      name: 'AUD/JPY_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Australasian',
      epics: [{ epic: 'CS.D.AUDJPY.MINI.IP' }]
    },
    {
      name: 'AUD/UAD_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Australasian',
      epics: [{ epic: 'CS.D.AUDNZD.MINI.IP' }]
    },
    {
      name: 'AUD/NZD_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Major FX',
      epics: [{ epic: 'CS.D.AUDUAD.MINI.IP' }]
    },
    {
      name: 'CAD/CHF_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Minor FX',
      epics: [{ epic: 'CS.D.CADCHF.MINI.IP' }]
    },
    {
      name: 'CAD/JPY_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Minor FX',
      epics: [{ epic: 'CS.D.CADJPY.MINI.IP' }]
    },
    {
      name: 'EUR/AUD_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Australasian',
      epics: [{ epic: 'CS.D.EURAUD.MINI.IP' }]
    },
    {
      name: 'EUR/CAD_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Minor FX',
      epics: [{ epic: 'CS.D.EURCAD.MINI.IP' }]
    },
    {
      name: 'EUR/CHF_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Major FX',
      epics: [{ epic: 'CS.D.EURCHF.MINI.IP' }]
    },
    {
      name: 'EUR/GBP_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Major FX',
      epics: [{ epic: 'CS.D.EURGBP.MINI.IP' }]
    },
    {
      name: 'EUR/JPY_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Major FX',
      epics: [{ epic: 'CS.D.EURJPY.MINI.IP' }]
    },
    {
      name: 'EUR/NZD_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Australasian',
      epics: [{ epic: 'CS.D.EURNZD.MINI.IP' }]
    },
    {
      name: 'EUR/USD_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Major FX',
      epics: [{ epic: 'CS.D.EURUSD.MINI.IP' }]
    },
    {
      name: 'GBP/AUD_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Australasian',
      epics: [{ epic: 'CS.D.GBPAUD.MINI.IP' }]
    },
    {
      name: 'GBP/CAD_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Minor FX',
      epics: [{ epic: 'CS.D.GBPCAD.MINI.IP' }]
    },
    {
      name: 'GBP/CHF_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Minor FX',
      epics: [{ epic: 'CS.D.GBPCHF.MINI.IP' }]
    },
    {
      name: 'GBP/JPY_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Minor FX',
      epics: [{ epic: 'CS.D.GBPJPY.MINI.IP' }]
    },
    {
      name: 'GBP/NZD_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Australasian',
      epics: [{ epic: 'CS.D.GBPNZD.MINI.IP' }]
    },
    {
      name: 'GBP/USD_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Major FX',
      epics: [{ epic: 'CS.D.GBPUSD.MINI.IP' }]
    },
    {
      name: 'NZD/CAD_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Australasian',
      epics: [{ epic: 'CS.D.NZDCAD.MINI.IP' }]
    },
    {
      name: 'NZD/CHF_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Australasian',
      epics: [{ epic: 'CS.D.NZDCHF.MINI.IP' }]
    },
    {
      name: 'NZD/JPY_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Australasian',
      epics: [{ epic: 'CS.D.NZDJPY.MINI.IP' }]
    },
    {
      name: 'NZD/USD_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Australasian',
      epics: [{ epic: 'CS.D.NZDUSD.MINI.IP' }]
    },
    {
      name: 'USD/CAD_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Major FX',
      epics: [{ epic: 'CS.D.USDCAD.MINI.IP' }]
    },
    {
      name: 'USD/CHF_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Major FX',
      epics: [{ epic: 'CS.D.USDCHF.MINI.IP' }]
    },
    {
      name: 'USD/JPY_demo',
      type: 'CURRENCIES',
      treeName: 'Forex',
      branchName: 'Major FX',
      epics: [{ epic: 'CS.D.USDJPY.MINI.IP' }]
    }
  ]
}
