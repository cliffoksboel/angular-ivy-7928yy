import { Controller, MessagePattern } from "@nestjs/common";
import { TestService } from "./test.service";
import { LabElementDTO, MessageBrokerEnv, MessageBrokerMessage, StartLabTestDTO } from "@project-zero/models";

@Controller()
export class TestController {
  constructor(private readonly _testService: TestService) {}

  @MessagePattern({ message: MessageBrokerMessage.START_LAB_TEST, podEnv: MessageBrokerEnv.POD_ENV })
  async startLabtTest(startLabTestDTO: StartLabTestDTO): Promise<LabElementDTO> {
    return await this._testService.startLabTest(startLabTestDTO);
  }

  @MessagePattern({ message: MessageBrokerMessage.STOP_LAB_TEST, podEnv: MessageBrokerEnv.POD_ENV })
  async stopLabTest(): Promise<LabElementDTO> {
    return this._testService.stopLabTest();
  }
}