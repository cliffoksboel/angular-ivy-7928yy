import { Injectable, Logger } from "@nestjs/common";
import { MessageBrokerService } from "../../shared";
import { RpcException } from "@nestjs/microservices";
import { StartLabTestDTO, LabElementDTO, MessageBrokerMessage, AccountDetailsDTO, UpdateLabTestDTO, TestStatus, MarketTreeDTO, MessageBrokerEvent, AppSettingsDTO, MessageBrokerEnv, UpdateAppSettingsDTO } from "@project-zero/models";

@Injectable()
export class LiveTestService {
  private readonly _logger = new Logger(LiveTestService.name);

  constructor(private readonly _messageBrokerService: MessageBrokerService) {}

  async startLiveTest({ labElementId, testId, testType, timeframe, positionsPlaned, selectedMarkets }: StartLabTestDTO): Promise<LabElementDTO> {
    // send signal to login to IG
    const accountId = await this._messageBrokerService.send<string>(MessageBrokerMessage.INITIALIZE_IG_LOGIN);

    // throw and log error if not found
    if (!accountId) {
      const msg = `Could not login to IG`;
      this._logger.error('startupApplication(): ' + msg)
      throw new RpcException(msg);
    }

    // get account balance
    const { balance: { funds }} = await this._messageBrokerService.send<AccountDetailsDTO>(MessageBrokerMessage.GET_ACCOUNT_FROM_IG, accountId);

    // update labTest
    const updateLabTestDTO: UpdateLabTestDTO = {
      status: TestStatus.IN_PROGRESS,
      initialValues: {
        initialAccountSize: funds,
        timeframe,
        positionsPlaned,
        startedTimestamp: Date.now(),
        selectedMarkets
      }
    }
    const labElement = await this._messageBrokerService.send<LabElementDTO>(MessageBrokerMessage.UPDATE_LAB_TEST, { testId, updateLabTestDTO});

    // generate market tree (+save in db)
    const marketTree = await this._messageBrokerService.send<MarketTreeDTO>(MessageBrokerMessage.REFRESH_MARKET_TREE, selectedMarkets);

    // get epic data from IG and update in db
    await this._messageBrokerService.emit(MessageBrokerEvent.UPDATE_INSTRUMENTS, marketTree);

    // set appSettings (test settings)
    const { tradingRules } = await this._messageBrokerService.send<AppSettingsDTO>(MessageBrokerMessage.GET_APP_SETTINGS, {}, MessageBrokerEnv.PROD);
    const appSettings: UpdateAppSettingsDTO = {
      markets: {
        selectedMarkets,
        selectedInstruments: marketTree.instruments.map(instrument => instrument.name),
        selectedEpics: marketTree.instruments.map(instrument => instrument.epics[0].epic),
      },
      tradingAccountId: accountId,
      strategy: {
        riskManagement: labElement.riskManagement,
        strategyIds: labElement.strategyIds,
        strategySettings: labElement.strategySettings,
      },
      tradingRules,
      activeTest: {
        labElementId,
        testId,
        type: testType,
      }
    };
    await this._messageBrokerService.send(MessageBrokerMessage.UPDATE_APP_SETTINGS, appSettings);

    // start listening to streams
    this._messageBrokerService.emit(MessageBrokerEvent.INITIATE_STREAMING_WITH_IG);

    // initialize schedulers
    /* ----------- MISSING ------------- */

    return labElement;
  }

  async stopLiveTest(): Promise<LabElementDTO> {
    
  }
}
