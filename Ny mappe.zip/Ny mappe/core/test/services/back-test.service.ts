import { Injectable } from "@nestjs/common";
import { MessageBrokerService } from "../../shared";
import { StartLabTestDTO, LabElementDTO, UpdateLabTestDTO, TestStatus, MessageBrokerMessage, UpdateAppSettingsDTO, MessageBrokerEvent } from "@project-zero/models";
import { ExchangeStreamingService } from "../exchange-streaming/exchange-streaming.service";
import { BACK_TEST_MARKET_TREE } from "../models";

@Injectable()
export class BackTestService {
  constructor(
    private readonly _messageBrokerService: MessageBrokerService,
    private readonly _backTestExchangeStreamingService: ExchangeStreamingService
  ) {}

  async startBackTest({ labElementId, testId, testType, timeframe, positionsPlaned, initialAccountSize }: StartLabTestDTO): Promise<LabElementDTO> {
    // update labTest
    const updateLabTestDTO: UpdateLabTestDTO = {
      status: TestStatus.IN_PROGRESS,
      initialValues: {
        initialAccountSize,
        timeframe,
        positionsPlaned,
        startedTimestamp: Date.now()
      }
    }
    const labElement = await this._messageBrokerService.send<LabElementDTO>(MessageBrokerMessage.UPDATE_LAB_TEST, { testId, updateLabTestDTO});

    // generate market tree (+save in db), instruments and epics
    const marketTree = BACK_TEST_MARKET_TREE;

    // get epic data from IG and update in db
    await this._messageBrokerService.emit(MessageBrokerEvent.UPDATE_INSTRUMENTS, marketTree);

    // set appSettings (test settings)
    const appSettings: UpdateAppSettingsDTO = {
      markets: {
        selectedMarkets: marketTree.selectedMarkets,
        selectedInstruments: marketTree.instruments.map(instrument => instrument.name),
        selectedEpics: marketTree.instruments.map(instrument => instrument.epics[0].epic),
      },
      tradingAccountId: 'back-test-account',
      strategy: {
        riskManagement: labElement.riskManagement,
        strategyIds: labElement.strategyIds,
        strategySettings: labElement.strategySettings,
      },
      tradingRules: {
        allowNewTrades: true,
        suspendAllTrading: false
      },
      activeTest: {
        labElementId,
        testId,
        type: testType,
      }
    };
    await this._messageBrokerService.send(MessageBrokerMessage.UPDATE_APP_SETTINGS, appSettings);

    // start streaming snapshots
    this._backTestExchangeStreamingService.startStreamingSnapshots();

    return labElement;
  }

  async stopBackTest(testId: string): Promise<void> {
    // stop opening new positions
    const updateAppSettings: UpdateAppSettingsDTO = {
      tradingRules: {
        allowNewTrades: false
      }
    }
    await this._messageBrokerService.send(MessageBrokerMessage.UPDATE_APP_SETTINGS, updateAppSettings);

    // stop streaming snapshots
    /* ---------------- MISSING ---------------- */

    // delete all open positions related to test
    await this._messageBrokerService.send(MessageBrokerMessage.DELETE_OPEN_POSITIONS_RELATED_TO_TEST, testId);
  }
}
