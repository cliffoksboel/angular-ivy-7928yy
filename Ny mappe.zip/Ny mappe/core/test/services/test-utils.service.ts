import { Injectable } from "@nestjs/common";
import { IRiskManagement, ITestResults, PositionDTO, PositionType } from "@project-zero/models";

@Injectable()
export class TestUtilsService {
  calculateTestResults(positions: PositionDTO[], initialAccountSize: number, cumulativeAccountBalance: number[], riskManagement: IRiskManagement): ITestResults {
    let winningPositions = 0;
    let losingPositions = 0;
    let longPositions = 0;
    let longPositionWins = 0;
    let shortPositions = 0;
    let shortPositionWins = 0;
    let maxConsecutiveWins = 0;
    let maxConsecutiveLosses = 0;
    let consecWinCounter = 0;
    let consecLossesCounter = 0;
    let largestWinningPositionPercent = 0;
    let largestLosingPositionPercent = 0;
    let grossProfit = 0;
    let grossLoss = 0;
    let firstPositionTimestamp;
    let lastPositionTimestamp;

    // iterate positions
    positions.forEach((position, index)=> {
      // PERIOD
      const minDate = Math.min(...position.trades.map(trade => { return trade.open.timestamp }));
      const maxDate = Math.max(...position.trades.map(trade => { return trade.close.timestamp }));
      if (!firstPositionTimestamp || minDate < firstPositionTimestamp) firstPositionTimestamp = minDate;
      if (!lastPositionTimestamp || maxDate > lastPositionTimestamp) lastPositionTimestamp = maxDate;

      // select between positive and negative profit
      if (position.profitPercent > 0) {
        // POSITIONS
        winningPositions++;
        consecWinCounter++;
        if (consecWinCounter > maxConsecutiveWins) maxConsecutiveWins = consecWinCounter;
        if (positions[index + 1].profitPercent <= 0) consecWinCounter = 0;
        if (position.profitPercent > largestWinningPositionPercent) largestWinningPositionPercent = position.profitPercent;
        if (position.openRecommendation.strategiesAssessment[0].positionType === PositionType.LONG) {
          longPositions++;
          longPositionWins++;
        } else {
          shortPositions++;
          shortPositionWins++;
        }

        // PROFIT
        grossProfit += position.profit;
      } else {
        // POSITIONS
        losingPositions++;
        consecLossesCounter++;
        if (consecLossesCounter > maxConsecutiveLosses) maxConsecutiveLosses = consecLossesCounter;
        if (positions[index + 1].profitPercent > 0) consecLossesCounter = 0;
        if (position.profitPercent < largestLosingPositionPercent) largestLosingPositionPercent = position.profitPercent;
        if (position.openRecommendation.strategiesAssessment[0].positionType === PositionType.LONG) {
          longPositions++;
        } else {
          shortPositions++;
        }

        // PROFIT
        grossLoss += position.profit;
      }
    });

    // calculate POSITIONS
    const totalPositions = winningPositions + losingPositions;
    const winningPositionsPercent = winningPositions / totalPositions;
    const losingPositionsPercent = losingPositions / totalPositions;
    const winningLongPositionsPercent = longPositionWins / longPositions;
    const winningShortPositionsPercent = shortPositionWins / shortPositions;

    // calculate PROFIT
    const netProfit = grossProfit + grossLoss;
    const netProfitPercent = netProfit / initialAccountSize;
    const avgNetProfit = netProfit / totalPositions;
    const avgNetProfitPercent = netProfitPercent / totalPositions;
    const avgGrossProfit = grossProfit / winningPositions;
    const avgGrossLoss = grossLoss / losingPositions;
    const profitFactor = grossProfit / -grossLoss;

    // calculate PERIOD
    const periodLength = lastPositionTimestamp - firstPositionTimestamp;

    // calculate ROI
    const dailyNetProfitPercent = netProfitPercent / periodLength * (24 * 60 * 60 * 1000);
    const yearlyNetProfitPercent = dailyNetProfitPercent * 365;
    const monthlyNetProfitPercent = yearlyNetProfitPercent / 12;

    // calculate RISK
    const riskRewardRatio = `1 : ${profitFactor}`;

    // calculate EQUITY
    const drawdown = [];
    for ( let i = 1; i < cumulativeAccountBalance.length; i++) {
      drawdown.push((Math.min(...cumulativeAccountBalance.slice(i)) / cumulativeAccountBalance[i - 1]) - 1);
    }
    const maxDrawdown = Math.min(...drawdown);
    const absDrawdown = Math.min(...cumulativeAccountBalance) < 0 ? (Math.min(...cumulativeAccountBalance) - initialAccountSize) / initialAccountSize : 0;

    // calculate SCORE
    let score = 0;
    // compare maxConsecutiveLosses vs maxConsecutiveWins 15 points,
    if (maxConsecutiveLosses < maxConsecutiveWins) score += 15 * Math.min(maxConsecutiveWins / maxConsecutiveLosses - 1 , 1);

    // largestLosingPositionPercent 10 points, should not be bigger than risk ratio
    const expectedMaxLosingPercent = avgNetProfitPercent / riskManagement.riskRewardRatio;
    if (largestLosingPositionPercent <= expectedMaxLosingPercent) score += 10;
    else score += 10 * (1 - Math.min(largestLosingPositionPercent / riskManagement.minProfitPerTrade, 1));

    // profitFactor 25 points, compare profitFactor with expected riskRewardRatio from riskManagement
    if (profitFactor > 1) score += 25 * Math.min(profitFactor / riskManagement.riskRewardRatio, 1);

    // winningPositionsPercent 12.5 points, winRate should be more than 0.5
    if (winningPositionsPercent >= 0.5) score += 12.5 * ((winningPositionsPercent - 0.5) / 0.5);

    // avgNetProfitPercent 12.5 points, compare averageNetProfit with expected minProfitPerTrade from riskManagement
    if (avgNetProfitPercent > 0) score += 12.5 * Math.min(avgNetProfitPercent / riskManagement.minProfitPerTrade, 1);

    // maxDrawdown 15 points, should be close to 0
    if (maxDrawdown === 0) score += 15
    else score += 15 * (1 - Math.min(Math.abs(maxDrawdown / netProfitPercent), 1));

    // absoluteDrawdown 10 points, should be 0, max is max drawdown
    if (absDrawdown === 0) score += 10;
    else score += 10 * (1 - Math.min(Math.abs(absDrawdown / maxDrawdown), 1));

    return {
      netProfit,
      netProfitPercent,
      avgNetProfit,
      avgNetProfitPercent,
      grossProfit,
      grossLoss,
      avgGrossProfit,
      avgGrossLoss,
      profitFactor,
      totalPositions,
      winningPositions,
      losingPositions,
      winningPositionsPercent,
      losingPositionsPercent,
      shortPositions,
      longPositions,
      winningShortPositionsPercent,
      winningLongPositionsPercent,
      maxConsecutiveWins,
      maxConsecutiveLosses,
      largestWinningPositionPercent,
      largestLosingPositionPercent,
      firstPositionTimestamp,
      lastPositionTimestamp,
      periodLength,
      maxDrawdown,
      absDrawdown,
      dailyNetProfitPercent,
      monthlyNetProfitPercent,
      yearlyNetProfitPercent,
      riskRewardRatio,
      score,
    };
  }

  convertToTimeString(timeInMs: number): string {
    let timeLeft = timeInMs;
    let d = 1000 * 60 * 60 * 24;

    const days = Math.floor(timeInMs / d);
    timeLeft = timeLeft % d;
    d = d / 24;

    const hours = Math.floor(timeLeft / d);
    timeLeft = timeLeft % d;
    d = d / 60;

    const minutes = Math.floor(timeLeft / d);
    timeLeft = timeLeft % d;
    d = d / 60;

    const seconds = Math.floor(timeLeft / d);
    const milliseconds = timeLeft % d;

    return `${days > 0 ? days + 'd ' : ''}${hours > 0 ? hours + 'h ' : ''}${minutes > 0 ? minutes + 'm ' : ''}${seconds > 0 ? seconds + 's ' : ''}${milliseconds > 0 ? milliseconds + 'ms' : ''}`;
  }
}
