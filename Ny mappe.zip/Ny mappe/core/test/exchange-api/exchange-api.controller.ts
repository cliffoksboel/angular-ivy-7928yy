import { Controller } from "@nestjs/common";
import { ExchangeApiService } from "./exchange-api.service";
import { MessagePattern } from "@nestjs/microservices";
import { ConfirmedTradeDTO, IClosePositionSettings, IOpenPositionSettings, MessageBrokerEnv, MessageBrokerMessage } from "@project-zero/models";

@Controller()
export class ExchangeApiController {
  constructor(private readonly _exchangeApiService: ExchangeApiService) {}

  @MessagePattern({ message: MessageBrokerMessage, podEnv: MessageBrokerEnv.DEMO })
  async createPosition(settings: IOpenPositionSettings): Promise<ConfirmedTradeDTO> {
    return await this._exchangeApiService.createPosition(settings);
  }

  @MessagePattern({ message: MessageBrokerMessage, podEnv: MessageBrokerEnv.DEMO })
  async closePosition(settings: IClosePositionSettings): Promise<ConfirmedTradeDTO> {
    return await this._exchangeApiService.closePosition(settings);
  }
}
