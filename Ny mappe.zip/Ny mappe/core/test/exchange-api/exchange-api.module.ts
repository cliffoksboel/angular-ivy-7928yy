import { Global, Module } from "@nestjs/common";
import { ExchangeApiController } from "./exchange-api.controller";
import { ExchangeApiService } from "./exchange-api.service";

@Global()
@Module({
  controllers: [ExchangeApiController],
  providers: [ExchangeApiService]
})
export class ExchangeApiModule {}
