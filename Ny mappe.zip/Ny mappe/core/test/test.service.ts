import { Injectable } from "@nestjs/common";
import { BackTestService, LiveTestService, TestUtilsService } from "./services";
import { LabElementDTO, MessageBrokerMessage, PositionDTO, StartLabTestDTO, TestDTO, TestStatus, TestType, UpdateLabTestDTO } from "@project-zero/models";
import { CacheService, MessageBrokerService } from "../shared";

@Injectable()
export class TestService {
  constructor(
    private readonly _cacheService: CacheService,
    private readonly _backTestService: BackTestService,
    private readonly _liveTestService: LiveTestService,
    private readonly _testUtilsService: TestUtilsService,
    private readonly _messageBrokerService: MessageBrokerService
  ) {}

  async startLabTest(startLabTestDTO: StartLabTestDTO): Promise<LabElementDTO> {
    if (startLabTestDTO.testType === TestType.BACK_TEST) return this._backTestService.startBackTest(startLabTestDTO);
    return this._liveTestService.startLiveTest(startLabTestDTO);
  }

  async stopLabTest(): Promise<LabElementDTO> {
    // get active test
    const { activeTest: { labElementId, testId, type }} = await this._cacheService.getAppSettings();

    // stop live test og back test
    if (type === TestType.BACK_TEST) await this._backTestService.stopBackTest(testId);
    else await this._liveTestService.stopLiveTest();

    // close and finish test
    const updatedLabElement = await this.closeAndFinishTest(labElementId, testId, TestStatus.CANCELLED);

    return updatedLabElement;
  }

  /**********
  ** UTILS **
  **********/
  private async closeAndFinishTest(labElementId: string, testId: string, status: TestStatus): Promise<LabElementDTO> {
    // get initial account size anf started timestamp
    const { tests, riskManagement } = await this._messageBrokerService.send<LabElementDTO>(MessageBrokerMessage.GET_LAB_ELEMENT, labElementId);
    const { initialValues: { startedTimestamp, initialAccountSize }} = tests.find(test => test._id === testId);

    // get test positions
    const positions = await this._messageBrokerService.send<PositionDTO[]>(MessageBrokerMessage.GET_POSITIONS_BY_TEST, testId);

    // set finished values
    const finishedTimestamp = Date.now();
    const timeToComplete = this._testUtilsService.convertToTimeString(finishedTimestamp - startedTimestamp);
    const cumulativeAccountBalance = [initialAccountSize];
    let tradesCompleted = 0;

    const sortedPositionByCloseDate = positions.sort((a, b) => a.closeTimestamp - b.closeTimestamp);
    sortedPositionByCloseDate.forEach((position, index) => {
      cumulativeAccountBalance.push(cumulativeAccountBalance[index] + position.profit);
      tradesCompleted += position.trades.length;
    });

    // calculate results
    const results = this._testUtilsService.calculateTestResults(positions, initialAccountSize, cumulativeAccountBalance, riskManagement);

    // update test in db
    const updateTestDTO: UpdateLabTestDTO = {
      status,
      finishValues: {
        finishedAccountSize: cumulativeAccountBalance[cumulativeAccountBalance.length - 1],
        tradesCompleted,
        positionsCompleted: positions.length,
        timeToComplete,
        finishedTimestamp,
        cumulativeAccountBalance
      },
      results
    }
    const updatedLabElement = await this._messageBrokerService.send<LabElementDTO>(MessageBrokerMessage.UPDATE_LAB_TEST, { testId, updateTestDTO });

    return updatedLabElement;
  }
}