import { MongooseModule } from '@nestjs/mongoose';
import { Global, Module } from "@nestjs/common";
import { ExchangeStreamingModule } from "./exchange-streaming/exchange-streaming.module";
import { ExchangeApiModule } from "./exchange-api/exchange-api.module";
import { ConfigModule, ConfigService } from '@nestjs/config';
import { MessageBrokerEnv } from '@project-zero/models';
import { BackTestService, LiveTestService, TestUtilsService } from './services';
import { TestController } from './test.controller';
import { TestService } from './test.service';

const MODULES = [
  ExchangeStreamingModule,
  ExchangeApiModule
];

@Global()
@Module({
  imports: [
    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        uri: `mongodb://${configService.get('DB_HOST')}:${configService.get('DB_PORT')}/${MessageBrokerEnv.DEMO}`,
      }),
      inject: [ConfigService],
      connectionName: MessageBrokerEnv.DEMO
    }),
    ...MODULES
  ],
  controllers: [TestController],
  providers: [
    TestService, 
    BackTestService, 
    LiveTestService, 
    TestUtilsService
  ],
})
export class TestModule {}
