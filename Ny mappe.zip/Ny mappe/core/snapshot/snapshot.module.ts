import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { SnapshotController } from "./snapshot.controller";
import { Snapshot, SnapshotSchema } from "./schema/snapshot.schema";
import { SnapshotService } from "./snapshot.service";
import { MessageBrokerEnv } from "@project-zero/models";

@Module({
  imports: [MongooseModule.forFeature([{ name: Snapshot.name, schema: SnapshotSchema }], MessageBrokerEnv.POD_ENV)],
  controllers: [SnapshotController],
  providers: [SnapshotService]
})
export class SnapshotModule {}
