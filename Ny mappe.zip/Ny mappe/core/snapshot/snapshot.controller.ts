import { Controller } from "@nestjs/common";
import { EventPattern, MessagePattern } from "@nestjs/microservices";
import { CreateSnapshotDTO, MessageBrokerEvent, MessageBrokerMessage, SnapshotDTO } from "@project-zero/models";
import { SnapshotService } from "./snapshot.service";

@Controller()
export class SnapshotController {
  constructor(private readonly _snapshotService: SnapshotService) {}

  @MessagePattern(MessageBrokerMessage.GET_SNAPSHOTS)
  async getSnapshotsBySearch(data: { instrumentName: string, count: number }): Promise<SnapshotDTO[]> {
    return this._snapshotService.getSnapshotsBySearch(data.instrumentName, data.count);
  }

  @EventPattern(MessageBrokerEvent.SAVE_NEW_SNAPSHOT)
  async createSnapshot(createSnapshotDTO: CreateSnapshotDTO): Promise<void> {
    this._snapshotService.createSnapshot(createSnapshotDTO);
  }
}
