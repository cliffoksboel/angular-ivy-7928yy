import { Injectable, Logger } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { RpcException } from "@nestjs/microservices";
import { CreateSnapshotDTO, SnapshotDTO } from "@project-zero/models";
import { Snapshot, SnapshotDocument } from "./schema/snapshot.schema";

@Injectable()
export class SnapshotService {
  private readonly _logger = new Logger(SnapshotService.name);

  constructor(@InjectModel(Snapshot.name) private readonly _snapshotModel: Model<SnapshotDocument>) {}

  async createSnapshot(createSnapshotDTO: CreateSnapshotDTO): Promise<void> {
    try {
      // save new snapshot in DB
      await this._snapshotModel.create(createSnapshotDTO);
    } catch(err) {
      this._logger.error('createSnapshot(): ' + err.message);
      throw new RpcException(err.message);
    }
  }

  async getSnapshotsBySearch(instrumentName: string, count: number): Promise<SnapshotDTO[]> {
    // find all snapshots in db
    let snapshotDocs = await this._snapshotModel.find({ instrumentName });

    // throw and log error if not found
    if (!snapshotDocs || snapshotDocs.length === 0) {
      const msg = `No snapshots found`;
      this._logger.error('getSnapshotsBySearch(): ' + msg)
      throw new RpcException(msg);
    }

    // sort by timestamp
    snapshotDocs = snapshotDocs.sort((a, b) => { return a-b });

    // select only last 'count' number of snapshots
    snapshotDocs = snapshotDocs.slice(-count);

    return snapshotDocs;
  }

  async deleteAllSnapshots(): Promise<void> {
    await this._snapshotModel.deleteMany({});
  }
}
