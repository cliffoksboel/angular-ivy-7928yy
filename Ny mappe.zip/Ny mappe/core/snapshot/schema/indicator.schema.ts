import { Prop, Schema } from "@nestjs/mongoose";
import { SupportValues } from "./support-values.schema";
import { IndicatorTrend } from "@project-zero/models";

@Schema({_id: false})
export class Indicator {
  @Prop({required: true})
  id: string;

  @Prop()
  value: number;

  @Prop()
  valueBBupper: number;

  @Prop()
  valueBBmiddle: number;

  @Prop()
  valueBBlower: number;

  @Prop()
  supportValues: SupportValues;

  @Prop()
  valueMACD: number;

  @Prop()
  valueMACDSignal: number;

  @Prop()
  valueMACDHistogram: number;

  @Prop()
  valuePSAR: number;

  @Prop({type: String, enum: IndicatorTrend})
  valuePSARTrend: IndicatorTrend;

  @Prop()
  valueK: number;

  @Prop()
  valueD: number;
}
