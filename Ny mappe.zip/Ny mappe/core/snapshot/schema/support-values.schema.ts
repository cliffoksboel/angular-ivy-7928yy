import { Prop, Schema } from "@nestjs/mongoose";

@Schema({_id: false})
export class SupportValues {
  @Prop()
  ATR: number;

  @Prop()
  ApDM: number;

  @Prop()
  AnDM: number;

  @Prop()
  fastEma: number;

  @Prop()
  slowEma: number;

  @Prop()
  ep: number;

  @Prop()
  af: number;

  @Prop()
  RSIs: number[];
}
