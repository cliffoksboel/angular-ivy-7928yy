import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { StrategyResolution } from "@project-zero/models";
import { Transform } from "class-transformer";
import { HydratedDocument } from "mongoose";
import { BidOffer } from "./bid-offer.schema";
import { PositionRecommendation } from "../../position/schema/position-recommendation.schema";
import { Indicator } from "./indicator.schema";

export type SnapshotDocument = HydratedDocument<Snapshot>;

@Schema()
export class Snapshot {
  @Transform(({ value }) => value.toString())
  _id: string;

  @Prop({required: true})
  instrumentId: string;

  @Prop({required: true})
  instrumentName: string;

  @Prop({required: true})
  timestamp: number;

  @Prop({required: true, type: String, enum: StrategyResolution})
  resolution: StrategyResolution;

  @Prop({required: true})
  open: number;

  @Prop({required: true})
  close: number;

  @Prop({required: true})
  high: number;

  @Prop({required: true})
  low: number;

  @Prop({required: true})
  volume: number;

  @Prop({required: true})
  bidOffer: BidOffer;

  @Prop({required: true})
  indicators: Indicator[];

  @Prop({required: true})
  recommendation: PositionRecommendation;
}

export const SnapshotSchema = SchemaFactory.createForClass(Snapshot);
