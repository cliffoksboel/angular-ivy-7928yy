import { Prop, Schema } from "@nestjs/mongoose";

@Schema({_id: false})
export class BidOffer {
  @Prop({required: true})
  epic: string;

  @Prop({required: true})
  timestamp: number;

  @Prop({required: true})
  volume: number;

  @Prop({required: true})
  offerOpen: number;

  @Prop({required: true})
  offerHigh: number;

  @Prop({required: true})
  offerLow: number;

  @Prop({required: true})
  offerClose: number;

  @Prop({required: true})
  bidOpen: number;

  @Prop({required: true})
  bidHigh: number;

  @Prop({required: true})
  bidLow: number;

  @Prop({required: true})
  bidClose: number;
}
