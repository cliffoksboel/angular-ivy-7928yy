export const MessageBrokerEvent = {
  LIVETEST_CLEANUP: 'livetest-cleanup', // received by ANALYST - emitted by CORE
  STOP_LIVETEST_TRADING: 'stop-livetest-trading', // received by ANALYST, BROKER - emitted by CORE

  /* POSITION */
  POSITION_CLOSED: 'position-closed', // received by DATA - emitted by BROKER
  UPDATE_POSITION_TARGETS: 'update-position-targets', // received by DATA - emitted by BROKER
  POSITION_OPENED: 'position-opened', // received by DATA - emitted by BROKER

  /* SETTINGS */
  STARTUP_APPLICATION: 'startup-application', // received by ANALYST - emitted by CORE
  UPDATE_APP_SETTINGS: 'update-app-settings', // received by DATA - emitted by API, CORE
  APP_SETTINGS_UPDATED: 'app-settings-updated', // received by ANALYST - emitted by CORE
  TOGGLE_DEALING_SUSPENDED: 'toggle-dealing-suspended', // received by CORE, BROKER - emitted by CORE
  INITIATE_STREAMING_WITH_IG: 'initiate-streaming-with-ig',
  TERMINATE_STREAMING_FROM_IG: 'terminate-streaming-from-ig',

  /* AUTH / USER */
  LOGOUT_FROM_IG: 'logout-from-ig', // received by IG-GATEWAY - emitted by CORE

  /* ACCOUNT */
  NEW_ACCOUNT_BALANCE_FROM_IG: 'new-account-balance-from-ig', // received by DATA - emitted by IG-GATEWAY

  /* MARKET */
  NEW_MARKET_DATA_FROM_IG: 'new-market-data-from-ig', // received by DATA - emitted by IG-GATEWAY

  /* SNAPSHOT */
  NEW_SNAPSHOTS_FROM_IG: 'new-snapshots-from-ig', // received by DATA - emitted by IG-GATEWAY
  SAVE_NEW_SNAPSHOT: 'save-new-snapshot',
}
