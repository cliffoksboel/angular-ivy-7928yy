export interface IAOSettings {
  shortPeriod: number;
  longPeriod: number;
}
