export interface IStochRSISettings {
  period: number;
  oversoldLevel: number;
  overboughtLevel: number;
}