export interface IIndicatorStandardSettings {
  period: number;
}
