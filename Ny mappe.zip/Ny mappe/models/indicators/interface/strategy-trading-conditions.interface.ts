export interface IStrategyTradingConditions {
  short: IPositionCondition;
  long: IPositionCondition;
}

interface IPositionCondition {
  conditions: string[];
  confirmations: string[],
  stopLoss: string
}
