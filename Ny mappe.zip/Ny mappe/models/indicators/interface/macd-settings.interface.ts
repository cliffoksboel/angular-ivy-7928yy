export interface IMACDSettings {
  fastEMAPeriod: number;
  slowEMAPeriod: number;
  signalLinePeriod: number;
}
