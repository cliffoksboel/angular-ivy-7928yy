export interface IEMAResult {
  value: number;
}