export interface IIndicatorSettings {
  period?: number;
  shortPeriod?: number;
  longPeriod?: number;
  stDevPeriod?: number;
  fastEMAPeriod?: number;
  slowEMAPeriod?: number;
  signalLinePeriod?: number;
  initialAcceleration?: number;
  accelerationStep?: number;
  accelerationLimit?: number;
  kPeriod?: number;
  kSmooting?: number;
  dSmoothing?: number;
  oversoldLevel?: number;
  overboughtLevel?: number;
}
