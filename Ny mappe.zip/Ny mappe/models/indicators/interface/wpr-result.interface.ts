export interface IWPRResult {
  value: number;
}