export interface ISOSettings {
  kPeriod: number;
  kSmoothing?: number;
  dSmoothing: number;
  oversoldLevel: number;
  overboughtLevel: number;
}
