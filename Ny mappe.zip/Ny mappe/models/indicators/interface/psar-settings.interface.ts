export interface IPSARSettings {
  initialAcceleration: number;
  accelerationStep: number;
  accelerationLimit: number;
}
