export interface IMACDResult {
  valueMACD: number;
  valueMACDSignal: number;
  valueMACDHistogram: number;
  supportValues: {
    fastEma: number;
    slowEma: number;
  }
}