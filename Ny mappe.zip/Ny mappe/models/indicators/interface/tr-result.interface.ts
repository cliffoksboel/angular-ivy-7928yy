export interface ITRResult {
  value: number;
}