export interface ISMAResult {
  value: number;
}