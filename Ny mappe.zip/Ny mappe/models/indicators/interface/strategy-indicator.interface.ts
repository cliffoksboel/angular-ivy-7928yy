import { Indicator } from "../enum";
import { IIndicatorSettings } from "./indicator-settings.interface";

export interface IStrategyIndicator {
  id: string;
  type: Indicator;
  settings: IIndicatorSettings;
}
