import { IndicatorTrend } from "../enum";

export interface IIndicatorOutput {
  value: number;
  band?: {
    upper: number;
    lower: number;
  };
  signal?: number;
  histogram?: number;
  trend?: IndicatorTrend;
  oscillator?: {
    K: number;
    D: number;
  };
  supportValues?: {
    ATR?: number;
    ApDM?: number;
    AnDM?: number;
    fastEma?: number;
    slowEma?: number;
    ep?: number;
    af?: number;
    RSIs?: number[];
  };
}
