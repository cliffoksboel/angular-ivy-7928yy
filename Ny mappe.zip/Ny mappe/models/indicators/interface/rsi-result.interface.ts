export interface IRSIResult {
  value: number;
}