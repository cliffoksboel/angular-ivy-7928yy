export interface ISOResult {
  valueK: number;
  valueD: number;
}
