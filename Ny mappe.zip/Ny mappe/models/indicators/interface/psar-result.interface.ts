import { IndicatorTrend } from "../enum";

export interface IPSARResult {
  valuePSAR: number;
  valuePSARTrend: IndicatorTrend;
  supportValues: {
    ep: number;
    af: number;
  }
}