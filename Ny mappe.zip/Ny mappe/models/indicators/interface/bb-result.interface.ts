export interface IBBResult {
  valueBBupper: number;
  valueBBmiddle: number;
  valueBBlower: number;
}