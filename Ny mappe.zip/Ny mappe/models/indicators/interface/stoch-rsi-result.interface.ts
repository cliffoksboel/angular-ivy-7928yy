export interface IStochRSIResult {
  value: number;
  supportValues: {
    RSIs: number[];
  };
}