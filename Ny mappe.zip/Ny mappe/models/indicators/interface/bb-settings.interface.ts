export interface IBBSettings {
  period: number;
  stDevPeriod: number;
}
