export interface IAOResult {
  value: number;
}