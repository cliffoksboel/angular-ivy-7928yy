export interface IATRResult {
  value: number;
}