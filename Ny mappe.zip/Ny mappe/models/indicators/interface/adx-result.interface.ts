export interface IADXResult {
  value: number;
  supportValues: { 
    ATR: number;
    AnDM: number;
    ApDM: number;
  }
}