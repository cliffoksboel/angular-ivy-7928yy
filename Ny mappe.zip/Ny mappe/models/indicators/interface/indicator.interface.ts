import { IIndicatorSettings } from "./indicator-settings.interface";

export interface IIndicator {
  type: string;
  id: string;
  settings: IIndicatorSettings;
}
