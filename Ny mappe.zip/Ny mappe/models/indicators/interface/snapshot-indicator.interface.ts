import { IndicatorTrend } from "../enum";
import { ILevelsOutput } from "./levels-output.interface";
import { ISOResult } from "./so-result.interface";

export interface ISnapshotIndicator {
  id: string;
  value?: number;
  valueBBupper?: number;
  valueBBmiddle?: number;
  valueBBlower?: number;
  valueMACD?: number;
  valueMACDSignal?: number;
  valueMACDHistogram?: number;
  valuePSAR?: number;
  valuePSARTrend?: IndicatorTrend;
  valueK?: number;
  valueD?: number;

  levels?: ILevelsOutput;
  
  
  supportValues?: {
    ATR?: number;
    ApDM?: number;
    AnDM?: number;
    fastEma?: number;
    slowEma?: number;
    ep?: number;
    af?: number;
    RSIs?: number[];
  };
}
