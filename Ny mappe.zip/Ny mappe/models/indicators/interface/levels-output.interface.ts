export interface ILevelsOutput {
  highs: number[];
  lows: [];
  resistance: number;
  support: number;
  swingHigh: number;
  swingLow: number;
}
