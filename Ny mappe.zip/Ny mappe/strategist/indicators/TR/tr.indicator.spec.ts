import { IIndicatorOutput } from '@project-zero/models';
import { TRIndicator } from './tr.indicator';

describe('TR Indicator', () => {
  let indicator: TRIndicator;

  beforeEach(() => {
    indicator = new TRIndicator();
  });

  describe('calculate', () => {
    it('should return an empty array', async () => {
      const expectedResult: IIndicatorOutput[] = [];
      const highPrices = [122.12, 124,75];
      const lowPrices: number[] = [];
      const closePrices = [107.87, 112.25];
      expect(indicator.calculate({ highPrices, lowPrices, closePrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 2 exact values', async () => {
      const expectedResult: IIndicatorOutput[] = [
        { value: 19.87000 },
        { value: 16.88000 }
      ];
      const highPrices = [122.12, 124.75];
      const lowPrices = [102.25, 109.62];
      const closePrices = [107.87, 112.25];
      expect(indicator.calculate({ highPrices, lowPrices, closePrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 3 exact values', async () => {
      const expectedResult: IIndicatorOutput[] = [
        { value: 19.87000 },
        { value: 16.88000 },
        { value: 18.81000 }
      ];
      const highPrices = [122.12, 124.75, 119.75];
      const lowPrices = [102.25, 109.62, 100.94];
      const closePrices = [107.87, 112.25, 102.75];
      const prevTRs = expectedResult.slice(0, 2);
      expect(indicator.calculate({ highPrices, lowPrices, closePrices, prevTRs })).toStrictEqual(expectedResult);
    });
  });
});
