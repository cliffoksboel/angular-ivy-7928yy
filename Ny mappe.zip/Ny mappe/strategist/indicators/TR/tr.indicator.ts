import { Injectable } from "@nestjs/common";
import { ISnapshotIndicator, ITRResult } from "@project-zero/models";
import { IConvertedSnapshotArray } from "../../models";

/*
*********** TRUE RANGE ***********
- It measures the daily range plus any gap from the closing price of the preceding day.

TR formula: max[(high − low), abs(high − prevClose), abs(low – prevClose)]
high = current high price
low = current low price
prevClose = previous close price

OBS!!! First TR in series = high - low
*/

@Injectable()
export class TRIndicator {
  calculate(id: string, snapshot: IConvertedSnapshotArray): ISnapshotIndicator {
    const { highPrices, lowPrices, closePrices } = snapshot;
    const prevTRs: ITRResult[] = [];
    snapshot.indicators.forEach(snapshot => {
      const prevTR = snapshot.find(indicator => indicator.id === id);
      if (prevTR) prevTRs.push(prevTR as ITRResult);
    });

    // set return values as empty array if not enough data points
    let calculatedTR: ITRResult = { value: NaN };

    // calculate tr for one point if prevTRs are not undefined
    if (prevTRs && prevTRs.length > 0) {
      const index = highPrices.length - 1;
      calculatedTR = this.calculateTRPoint(highPrices[index], lowPrices[index], closePrices[index - 1]);
    } else {
      // initiate TR array and calculate TR series if length of arrays are greater than 0
      const calculatedTRs = this.calculateArray(snapshot);
      calculatedTR = calculatedTRs[calculatedTRs.length - 1];
    }

    return {
      id,
      ...calculatedTR
    };
  }

  calculateArray(snapshot: IConvertedSnapshotArray): ITRResult[] {
    const { highPrices, lowPrices, closePrices } = snapshot;

    // set return values as empty array if not enough data points
    let calculatedTRs: ITRResult[] = [];

    // initiate TR array and calculate TR series if length of arrays are greater than 0
    if (highPrices.length > 0 && lowPrices.length > 0 && closePrices.length > 0) {
      for (let i = 0; i < highPrices.length; i++) {
        // set first value if index is 0
        if (i === 0) calculatedTRs = [this.calculateTRFirstPoint(highPrices[i], lowPrices[i])];
        else calculatedTRs = [
          ...calculatedTRs,
          this.calculateTRPoint(highPrices[i], lowPrices[i], closePrices[i - 1])
        ];
      }
    }

    return calculatedTRs;
  }

  /* returns TR value rounded to 5 decimals */
  private calculateTRPoint(highPrice: number, lowPrice: number, prevClosingPrice: number): ITRResult {
    return {
      value: Math.round(Math.max(highPrice - lowPrice, Math.abs(highPrice - prevClosingPrice), Math.abs(lowPrice - prevClosingPrice)) * 100000) / 100000
    }
  }

  private calculateTRFirstPoint(highPrice: number, lowPrice: number): ITRResult {
    return {
      value: Math.round((highPrice - lowPrice) * 100000) / 100000
    }
  }
}
