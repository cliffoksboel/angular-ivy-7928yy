import { Injectable } from "@nestjs/common";
import { ISnapshotIndicator, IIndicatorSettings, IAOResult } from "@project-zero/models";
import { IConvertedSnapshotArray } from "../../models";

/*
*********** AWESOME OSCILLATOR ***********
- The awesome oscillator is a market momentum indicator that is used to identify
  price reversals and corrections.
- It's one of the easiest but most effective trading tools that provide a wide range of signals.

AO formula: SMA5 - SMA34
Midpoint = (H+L)/2
*/

@Injectable()
export class AOIndicator {
  private _defaultShortPeriod = 5;
  private _defaultLongPeriod = 34;

  calculate(id: string, snapshot: IConvertedSnapshotArray, settings?: IIndicatorSettings): ISnapshotIndicator {
    const shortPeriod = settings && settings.shortPeriod ? settings.shortPeriod : this._defaultShortPeriod;
    const longPeriod = settings && settings.longPeriod ? settings.longPeriod : this._defaultLongPeriod;
    const { highPrices, lowPrices } = snapshot;
    let prevAOs:IAOResult[] = [];
    snapshot.indicators.forEach(snapshot => {
      const prevAO = snapshot.find(indicator => indicator.id === id);
      if (prevAO) prevAOs.push(prevAO as IAOResult);
    });

    // set return values as empty array if not enough data points
    let calculatedAO: IAOResult = { value: NaN };

    // calculate for one point if prevAOs
    if (prevAOs && prevAOs.length > 0) calculatedAO = this.calculatePoint(highPrices.slice(-longPeriod), lowPrices.slice(-longPeriod), shortPeriod, longPeriod);

    // initiate AO array if length of price arrays are greater or equal to long period
    else if (highPrices.length > longPeriod - 1) {
      const startIndex = longPeriod - 1;
      for (let i = startIndex; i < highPrices.length; i++) {
        prevAOs = [
          ...prevAOs,
          this.calculatePoint(highPrices.slice(i - startIndex, i + 1), lowPrices.slice(i - startIndex, i + 1), shortPeriod, longPeriod)
        ];
      }

      calculatedAO = prevAOs[prevAOs.length - 1];
    }

    return {
      id,
      ...calculatedAO
    };
  }

  private calculatePoint(highPrices: number[], lowPrices: number[], shortPeriod: number, longPeriod: number): IAOResult {
    // calculate midpoint arr
    const midPoints: number[] = []
    for (let i = 0; i < highPrices.length; i++) {
      midPoints.push(this.calculateMidPoint(highPrices[i], lowPrices[i]));
    }

    // calculate SMAs
    const shortSMA = this.calculateSMA(shortPeriod, midPoints.slice(-shortPeriod));
    const longSMA = this.calculateSMA(longPeriod, midPoints.slice(-longPeriod));

    // return calculate AO
    return { value: Math.round((shortSMA - longSMA) * 100) / 100 }
  }

  private calculateMidPoint(highPrice: number, lowPrice: number): number {
    return (highPrice + lowPrice) / 2;
  }

  private calculateSMA(period: number, prices: number[]): number {
    const total = prices.reduce((a, b) => a + b, 0);
    return total / period;
  }
}
