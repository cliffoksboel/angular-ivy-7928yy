import { AOIndicator } from './ao.indicator';
import { IIndicatorOutput } from '@project-zero/models';

describe('AO Indicator', () => {
  let indicator: AOIndicator;

  beforeEach(() => {
    indicator = new AOIndicator();
  });

  describe('calculate', () => {
    it('should return an empty array', async () => {
      const expectedResult: IIndicatorOutput[] = [];
      const highPrices = [122.12, 124.75, 119.75, 128.25, 128.00, 113.62, 122.31, 117.81, 134.25, 134.94, 119.62, 104.37, 104.75, 116.75, 118.64, 108.40, 118.05, 119.90, 119.00, 115.40, 110.09, 103.13, 112.10, 117.00, 124.70, 126.39, 109.30, 108.85, 104.00, 86.49, 80.95, 74.20, 82.85];
      const lowPrices = [102.25, 109.62, 100.94, 99.50, 101.25, 102.00, 105.50, 100.00, 110.25, 110.25, 86.94, 91.62, 80.06, 83.75, 99.10, 87.65, 90.05, 110.96, 111.10, 101.56, 98.86, 87.49, 91.34, 106.90, 113.21, 101.00, 95.76, 98.50, 83.34, 75.92, 66.10, 65.70, 65.85];
      expect(indicator.calculate({ highPrices, lowPrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 2 exact values', async () => {
      const expectedResult: IIndicatorOutput[] = [
        { value: -29.59 },
        { value: -31.12 }
      ];
      const highPrices = [122.12, 124.75, 119.75, 128.25, 128.00, 113.62, 122.31, 117.81, 134.25, 134.94, 119.62, 104.37, 104.75, 116.75, 118.64, 108.40, 118.05, 119.90, 119.00, 115.40, 110.09, 103.13, 112.10, 117.00, 124.70, 126.39, 109.30, 108.85, 104.00, 86.49, 80.95, 74.20, 82.85, 77.50, 79.79];
      const lowPrices = [102.25, 109.62, 100.94, 99.50, 101.25, 102.00, 105.50, 100.00, 110.25, 110.25, 86.94, 91.62, 80.06, 83.75, 99.10, 87.65, 90.05, 110.96, 111.10, 101.56, 98.86, 87.49, 91.34, 106.90, 113.21, 101.00, 95.76, 98.50, 83.34, 75.92, 66.10, 65.70, 65.85, 57.99, 54.01];
      expect(indicator.calculate({ highPrices, lowPrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 3 exact values', async () => {
      const expectedResult: IIndicatorOutput[] = [
        { value: -29.59 },
        { value: -31.12 },
        { value: -28.32 }
      ];
      const highPrices = [122.12, 124.75, 119.75, 128.25, 128.00, 113.62, 122.31, 117.81, 134.25, 134.94, 119.62, 104.37, 104.75, 116.75, 118.64, 108.40, 118.05, 119.90, 119.00, 115.40, 110.09, 103.13, 112.10, 117.00, 124.70, 126.39, 109.30, 108.85, 104.00, 86.49, 80.95, 74.20, 82.85, 77.50, 79.79, 88.11];
      const lowPrices = [102.25, 109.62, 100.94, 99.50, 101.25, 102.00, 105.50, 100.00, 110.25, 110.25, 86.94, 91.62, 80.06, 83.75, 99.10, 87.65, 90.05, 110.96, 111.10, 101.56, 98.86, 87.49, 91.34, 106.90, 113.21, 101.00, 95.76, 98.50, 83.34, 75.92, 66.10, 65.70, 65.85, 57.99, 54.01, 76.70];
      const prevAOs = expectedResult.slice(0, expectedResult.length - 1);
      expect(indicator.calculate({ highPrices, lowPrices, prevAOs })).toStrictEqual(expectedResult);
    });
  });
});
