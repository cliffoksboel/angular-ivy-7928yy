import { IStochRSIOutput } from '@project-zero/models';
import { RSIIndicator } from '../RSI/rsi.indicator';
import { StochRSIIndicator } from './stoch-rsi.indicator';

describe('Stoch RSI Indicator', () => {
  let indicator: StochRSIIndicator;
  let rsiIndicator: RSIIndicator;

  beforeEach(() => {
    rsiIndicator = new RSIIndicator();
    indicator = new StochRSIIndicator(rsiIndicator);
  });

  describe('calculate', () => {
    it('should return an empty array', async () => {
      const expectedResult: IStochRSIOutput[] = [];
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02, 112.62, 98.50, 93.50, 85.00, 112.00, 99.90, 96.18, 115.14, 111.80, 113.50, 105.21, 99.95, 91.72, 108.07, 115.59, 120.96, 107.89, 98.12];
      expect(indicator.calculate({ closePrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 2 exact values', async () => {
      const expectedResult: IStochRSIOutput[] = [
        { value: 0.28, supportValues: { RSIs: [47.37, 44.67, 53.87, 47.78, 50.70, 49.28, 46.79, 43.39, 42.12, 51.06, 58.55, 55.16, 54.66, 46.65] }},
        { value: 0.09, supportValues: { RSIs: [44.67, 53.87, 47.78, 50.70, 49.28, 46.79, 43.39, 42.12, 51.06, 58.55, 55.16, 54.66, 46.65, 43.68] }}
      ];
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02, 112.62, 98.50, 93.50, 85.00, 112.00, 99.90, 96.18, 115.14, 111.80, 113.50, 105.21, 99.95, 91.72, 108.07, 115.59, 120.96, 107.89, 98.12, 104.00, 83.76];
      expect(indicator.calculate({ closePrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 3 exact values', async () => {
      const expectedResult: IStochRSIOutput[] = [
        { value: 0.28, supportValues: { RSIs: [47.37, 44.67, 53.87, 47.78, 50.70, 49.28, 46.79, 43.39, 42.12, 51.06, 58.55, 55.16, 54.66, 46.65] }},
        { value: 0.09, supportValues: { RSIs: [44.67, 53.87, 47.78, 50.70, 49.28, 46.79, 43.39, 42.12, 51.06, 58.55, 55.16, 54.66, 46.65, 43.68] }},
        { value: 0.10, supportValues: { RSIs: [53.87, 47.78, 50.70, 49.28, 46.79, 43.39, 42.12, 51.06, 58.55, 55.16, 54.66, 46.65, 43.68, 43.82] }}
      ];
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02, 112.62, 98.50, 93.50, 85.00, 112.00, 99.90, 96.18, 115.14, 111.80, 113.50, 105.21, 99.95, 91.72, 108.07, 115.59, 120.96, 107.89, 98.12, 104.00, 83.76, 80.45];
      const prevStochRSIs = expectedResult.slice(0, 2);
      expect(indicator.calculate({ closePrices, prevStochRSIs })).toStrictEqual(expectedResult);
    });
  });
});
