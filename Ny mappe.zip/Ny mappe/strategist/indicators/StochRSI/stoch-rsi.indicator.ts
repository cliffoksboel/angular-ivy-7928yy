import { Injectable } from "@nestjs/common";
import { ISnapshotIndicator, IIndicatorSettings, IStochRSIResult } from "@project-zero/models";
import { RSIIndicator } from "../RSI/rsi.indicator";
import { IConvertedSnapshotArray } from "../../models";

/*
*********** STOCHASTIC RSI ***********
- A StochRSI reading above 0.8 is considered overbought, while a reading below 0.2 is
  considered oversold. On the zero to 100 scale, above 80 is overbought, and below 20 is oversold.
- Overbought doesn't necessarily mean the price will reverse lower, just like oversold
  doesn't mean the price will reverse higher. Rather the overbought and oversold conditions
  simply alert traders that the RSI is near the extremes of its recent readings.
- A reading of zero means the RSI is at its lowest level in 14 periods (or whatever lookback
  period is chosen). A reading of 1 (or 100) means the RSI is at the highest level in the last 14 periods.
- Other StochRSI values show where the RSI is relative to a high or low.

StochRSI formula: (currRSI - min[RSI]) / (max[RSI] - min[RSI])

currRSI = Current RSI reading
min[RSI] = Lowest RSI reading over the last 14 periods (or your chosen lookback interval)
max[RSI] = Highest RSI reading over the last 14 periods (or your chosen lookback interval)
*/

@Injectable()
export class StochRSIIndicator {
  private _defaultPeriod = 14;
  private _defaultOversoldLevel = 0.2;
  private _defaultOverboughtLevel = 0.8;
  private _rsiService = new RSIIndicator();

  calculate(id: string, snapshot: IConvertedSnapshotArray, settings?: IIndicatorSettings): ISnapshotIndicator {
    const { closePrices } = snapshot;
    let prevStochRSIs: IStochRSIResult[] = [];
    snapshot.indicators.forEach(snapshot => {
      const prevStochRSI = snapshot.find(indicator => indicator.id === id);
      if (prevStochRSI) prevStochRSIs.push(prevStochRSI as IStochRSIResult);
    });
    const period = settings && settings.period ? settings.period : this._defaultPeriod;
    const oversoldLevel = settings && settings.oversoldLevel ? settings.oversoldLevel : this._defaultOversoldLevel;
    const overboughtLevel = settings && settings.overboughtLevel ? settings.overboughtLevel : this._defaultOverboughtLevel;

    // set return values as empty array if not enough data points
    let calculatedStochRSI: IStochRSIResult = { 
      value: NaN,
      supportValues: {
        RSIs: []
      }
    };

    // calculate StochRSI for one point if prevStochRSIs are provided
    if (prevStochRSIs) calculatedStochRSI = this.calculatePoint({ ...snapshot, closePrices: closePrices.slice(-(period + 1)) }, period, prevStochRSIs.slice(-1))

    // calculate StochRSI recursively if length of closing prices are greater than 2 x period
    else if (closePrices.length > 2 * period - 1) {
      const startIndex = 2 * period - 1;
      for (let i = startIndex; i < closePrices.length; i++) {
        prevStochRSIs = [
          ...prevStochRSIs,
          this.calculatePoint({ ...snapshot, closePrices: closePrices.slice(i - startIndex, i + 1) }, period, prevStochRSIs)
        ];
      }

      calculatedStochRSI = prevStochRSIs[prevStochRSIs.length - 1];
    }

    return {
      id,
      ...calculatedStochRSI
    };
  }

  private calculatePoint(snapshot: IConvertedSnapshotArray, period: number, prevStochRSIs: IStochRSIResult[] = []): IStochRSIResult {
    // calculate RSI and set array of length period
    let RSIs: number[];
    if (prevStochRSIs.length === 0) {
      RSIs = this._rsiService.calculateArray(snapshot, { period }).map(rsi => rsi.value).slice(-period);
    } else {
      RSIs = [
        ...prevStochRSIs[prevStochRSIs.length - 1].supportValues.RSIs.slice(-(period - 1)),
        this._rsiService.calculate(`RSI-${period}`, { ...snapshot, indicators: []}, { period }).value!
      ]
    }

    // calculate min and max RSI values
    const minRSI = Math.min(...RSIs);
    const maxRSI = Math.max(...RSIs);
    const currRSI = RSIs[RSIs.length - 1];

    // return new StochRSI
    return {
      value: Math.round(((currRSI - minRSI) / (maxRSI - minRSI)) * 100) / 100,
      supportValues: {
        RSIs
      }
    }
  }
}
