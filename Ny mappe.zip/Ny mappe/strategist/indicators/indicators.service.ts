import { Injectable } from "@nestjs/common";
import { IStrategyIndicator, ISnapshotIndicators } from '@project-zero/models';
import { AOIndicator } from './AO/ao.indicator';
import { ADXIndicator } from './ADX/adx.indicator';
import { SMAIndicator } from './SMA/sma.indicator';
import { EMAIndicator } from './EMA/ema.indicator';
import { TRIndicator } from "./TR/tr.indicator";
import { ATRIndicator } from "./ATR/atr.indicator";
import { PSARIndicator } from "./PSAR/psar.indicator";
import { RSIIndicator } from "./RSI/rsi.indicator";
import { SOIndicator } from "./SO/so.indicator";
import { WPRIndicator } from "./WPR/wpr.indicator";
import { BBIndicator } from './BB/bb.indicator';
import { MACDIndicator } from './MACD/macd.indicator';
import { StochRSIIndicator } from './StochRSI/stoch-rsi.indicator';
import { IConvertedSnapshotArray, IIndicator } from "../models";

@Injectable()
export class IndicatorsService {
  private _indicators: { [id: string]: IIndicator } = {
    ADX: new ADXIndicator(),
    AO: new AOIndicator(),
    ATR: new ATRIndicator(),
    BB: new BBIndicator(),
    EMA: new EMAIndicator(),
    MACD: new MACDIndicator(),
    PSAR: new PSARIndicator(),
    RSI: new RSIIndicator(),
    SMA: new SMAIndicator(),
    SO: new SOIndicator(),
    StochRSI: new StochRSIIndicator(),
    TR: new TRIndicator(),
    WPR: new WPRIndicator()
  };

  calculateIndicators(indicators: IStrategyIndicator[], snapshot: IConvertedSnapshotArray): ISnapshotIndicators {
    // calculate new indicators values and set to cached snapshot
    const newIndicators: ISnapshotIndicators = {};
    indicators.forEach(indicator => {
      newIndicators[indicator.id] = this._indicators[indicator.type].calculate(indicator.id, snapshot, indicator.settings);
    });

    return newIndicators;
  }
}
