import { Injectable } from "@nestjs/common";
import { ISnapshotIndicator, ISOResult, ISOSettings } from "@project-zero/models";
import { IConvertedSnapshotArray } from "../../models";

/*
*********** STOCHASTIC OSCILLATOR ***********
- A stochastic oscillator is a popular technical indicator for generating overbought and oversold signals.
- It is a popular momentum indicator, first developed in the 1950s.
- Stochastic oscillators tend to vary around some mean price level, since they rely on an asset's price history.

SO formula:
%K: (close - lowest low) / (highest high - lowest low) * 100
%D: 3-period SMA of %K

Highest High = Highest price in the lookback period, typically 14 days.
Close = Most recent closing price.
Lowest Low = Lowest price in the lookback period, typically 14 days.
*/

@Injectable()
export class SOIndicator {
  private _defaultKPeriod = 14;
  private _defaultKSmoothing = 1;
  private _defaultDSmoothing = 3;

  calculate(id: string, snapshot: IConvertedSnapshotArray, settings?: ISOSettings): ISnapshotIndicator {
    const { closePrices, highPrices, lowPrices } = snapshot;
    let prevSOs: ISOResult[] = [];
    snapshot.indicators.forEach(snapshot => {
      const prevSO = snapshot.find(indicator => indicator.id === id);
      if (prevSO) prevSOs.push(prevSO as ISOResult);
    });
    const kPeriod = settings ? settings.kPeriod : this._defaultKPeriod;
    const dSmoothing = settings ? settings.dSmoothing : this._defaultDSmoothing;
    const kSmoothing = settings && settings.kSmoothing ? settings.kSmoothing : this._defaultKSmoothing;
    const totalKPeriod = kPeriod + kSmoothing - 1;

    // set return values as empty array if not enough data points
    let calculatedSO: ISOResult = { 
      valueD: NaN,
      valueK: NaN
    };

    // calculate SO for one point if prevSOs are provided
    if (prevSOs) {
      const valueK = this.calculateKPoint(highPrices.slice(-totalKPeriod), lowPrices.slice(-totalKPeriod), closePrices[closePrices.length - 1], kPeriod, kSmoothing);
      const valueD = this.calculateDPoint([...prevSOs.map(so => so.valueK), valueK].slice(-dSmoothing), dSmoothing);

      calculatedSO = {
        valueD,
        valueK
      };
    } else {
      // set total period to k period + d period minus 1 if no smoothing else 2
      const totalPeriod = kPeriod + dSmoothing - (kSmoothing > this._defaultKSmoothing ? 2 : 1);

      // calculate SO for all prices if length of prices is equal or greater than minLength
      if (highPrices.length >= totalPeriod && lowPrices.length >= totalPeriod && closePrices.length >= totalPeriod) {
        const startIndex = totalKPeriod - 1;
        for (let i = startIndex; i < highPrices.length; i++) {
          const valueK = this.calculateKPoint(highPrices.slice(i - startIndex, i + 1), lowPrices.slice(i - startIndex, i + 1), closePrices[i], kPeriod, kSmoothing);
          const valueD = this.calculateDPoint([...prevSOs.map(so => so.valueK), valueK].slice(-dSmoothing), dSmoothing);

          prevSOs = [ ...prevSOs, {
            valueD,
            valueK
          }];
        }

        calculatedSO = prevSOs[prevSOs.length - 1];
      }
    }

    return {
      id,
      ...calculatedSO
    };
  }

  private calculateKPoint(highPrices: number[], lowPrices: number[], currClose: number, kPeriod: number, kSmoothing: number): number {
    if (kSmoothing > this._defaultKSmoothing) {
      let kValues: number[] = [];

      const startIndex = kPeriod - 1;
      for (let i = startIndex; i < highPrices.length; i++) {
        const lowestLow = Math.min(...lowPrices.slice(i - startIndex, i + 1));
        const highestHigh = Math.max(...highPrices.slice(i - startIndex, i + 1));
        kValues = [
          ...kValues,
          (currClose - lowestLow) / (highestHigh - lowestLow) * 100
        ];
      }

      return Math.round(kValues.reduce((a, b) => a + b, 0) * 100) / 100;
    } else {
      const lowestLow = Math.min(...lowPrices);
      const highestHigh = Math.max(...highPrices);
      return Math.round(((currClose - lowestLow) / (highestHigh - lowestLow) * 100) * 100) / 100;
    }
  }

  private calculateDPoint(K: number[], dSmoothing: number): number {
    if (K.length < dSmoothing) return NaN;
    else return Math.round((K.reduce((a, b) => a + b, 0) / dSmoothing) * 100) / 100;
  }
}
