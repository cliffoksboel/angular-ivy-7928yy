import { Injectable } from "@nestjs/common";
import { ISnapshotIndicator, IIndicatorSettings, IBBResult } from "@project-zero/models";
import { IConvertedSnapshotArray } from "../../models";

/*
*********** BOLLINGER BANDS ***********
- Bollinger Bands is a technical analysis tool to generate oversold or overbought
  signals and was developed by John Bollinger.
- Three lines compose Bollinger Bands: A simple moving average, or the middle band,
  and an upper and lower band.
- The upper and lower bands are typically 2 standard deviations +/- from a 20-day
  simple moving average and can be modified.
- When the price continually touches the upper Bollinger Band, it can indicate an overbought signal.
- If the price continually touches the lower band it can indicate an oversold signal.

Bollinger Bands formula:
BOLU = MA(TP,n) + m ∗ σ[TP,n]
BOLD = MA(TP,n) − m ∗ σ[TP,n]

where:
BOLU = Upper Bollinger Band
BOLD = Lower Bollinger Band
MA = Moving average
TP (typical price) = (High + Low + Close) / 3
n = Number of days in smoothing period (typically 20)
m = Number of standard deviations (typically 2)
σ[TP,n]=Standard Deviation over last n periods of TP
*/

@Injectable()
export class BBIndicator {
  private _defaultPeriod = 20;
  private _defaultStDevPeriod = 2;

  calculate(id: string, snapshot: IConvertedSnapshotArray, settings?: IIndicatorSettings): ISnapshotIndicator {
    const { closePrices } = snapshot;
    let prevBBs: IBBResult[] = [];
    snapshot.indicators.forEach(snapshot => {
      const prevBB = snapshot.find(indicator => indicator.id === id);
      if (prevBB) prevBBs.push(prevBB as IBBResult);
    });
    const period = settings && settings.period ? settings.period : this._defaultPeriod;
    const stDevPeriod = settings && settings.stDevPeriod ? settings.stDevPeriod : this._defaultStDevPeriod;

    // set return values as empty array if not enough data points
    let calculatedBB: IBBResult = { 
      valueBBupper: NaN, 
      valueBBmiddle: NaN, 
      valueBBlower: NaN 
    };

    // calculate ema from prevValue if prevEMAs
    if (prevBBs) calculatedBB = this.calculatePoint(closePrices.slice(-period), period, stDevPeriod);

    else {
      // calculate BB for all closingPrices if length of closingPrices - period is greater or equal to period
      const startIndex = period - 1;
      if (closePrices.length > startIndex) {
        for (let i = startIndex; i < closePrices.length; i++) {
          prevBBs = [
            ...prevBBs,
            this.calculatePoint(closePrices.slice(i - startIndex, i + 1), period, stDevPeriod)
          ];
        }

        calculatedBB = prevBBs[prevBBs.length - 1];
      }
    }

    return {
      id,
      ...calculatedBB
    };
  }

  private calculatePoint(closePrices: number[], period: number, stDevPeriod: number): IBBResult {
    const MA = closePrices.reduce((a, b) => a + b, 0) / period;
    const stDev = this.calculateSTDEV(closePrices);

    return {
      valueBBupper: Math.round((MA + stDev * stDevPeriod) * 100000) / 100000,
      valueBBmiddle: Math.round((MA) * 100000) / 100000,
      valueBBlower: Math.round((MA - stDev * stDevPeriod) * 100000) / 100000
    };
  }

  private calculateSTDEV(closePrices: number[]): number {
    // Creating the mean with Array.reduce
    const mean = closePrices.reduce((acc, curr) => acc + curr, 0) / closePrices.length;

    // Assigning (value - mean) ^ 2 to every array item
    const diffArr = closePrices.map((price) => {
      return (Math.abs(price - mean)) ** 2
    });

    // Calculating the sum of updated array
    const sum = diffArr.reduce((acc, curr)=> acc + curr, 0);

    // Calculating the variance
    const variance = sum / closePrices.length

    // Returning the standard deviation
    return Math.sqrt(variance);
  }
}
