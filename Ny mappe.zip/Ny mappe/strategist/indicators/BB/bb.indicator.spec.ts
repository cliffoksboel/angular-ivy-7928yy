import { IBBOutput } from '@project-zero/models';
import { BBIndicator } from './bb.indicator';

describe('BB Indicator', () => {
  let indicator: BBIndicator;

  beforeEach(() => {
    indicator = new BBIndicator();
  });

  describe('calculate', () => {
    it('should return an empty array', async () => {
      const expectedResult: IBBOutput[] = [];
      const closePrices = [86.16, 89.09, 88.78, 90.32, 89.07, 91.15, 89.44, 89.18, 86.93, 87.68, 86.96, 89.43, 89.32, 88.72, 87.45, 87.26, 89.50, 87.90, 89.13];
      expect(indicator.calculate({ closePrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 2 exact values', async () => {
      const expectedResult: IBBOutput[] = [
        { upperBand: 91.29191, middleBand: 88.70850, lowerBand: 86.12509 },
        { upperBand: 91.94972, middleBand: 89.04550, lowerBand: 86.14128 }
      ];
      const closePrices = [86.16, 89.09, 88.78, 90.32, 89.07, 91.15, 89.44, 89.18, 86.93, 87.68, 86.96, 89.43, 89.32, 88.72, 87.45, 87.26, 89.50, 87.90, 89.13, 90.70, 92.90];
      expect(indicator.calculate({ closePrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 3 exact values', async () => {
      const expectedResult: IBBOutput[] = [
        { upperBand: 91.29191, middleBand: 88.70850, lowerBand: 86.12509 },
        { upperBand: 91.94972, middleBand: 89.04550, lowerBand: 86.14128 },
        { upperBand: 92.61325, middleBand: 89.24000, lowerBand: 85.86675 }
      ];
      const closePrices = [86.16, 89.09, 88.78, 90.32, 89.07, 91.15, 89.44, 89.18, 86.93, 87.68, 86.96, 89.43, 89.32, 88.72, 87.45, 87.26, 89.50, 87.90, 89.13, 90.70, 92.90, 92.98];
      const prevBBs = expectedResult.slice(0, 2);
      expect(indicator.calculate({ closePrices, prevBBs })).toStrictEqual(expectedResult);
    });
  });
});
