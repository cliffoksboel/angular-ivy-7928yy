import { Injectable } from "@nestjs/common";
import { ISnapshotIndicator, IIndicatorSettings, IADXResult } from "@project-zero/models";
import { IConvertedSnapshotArray } from "../../models";

/*
*********** AVERAGE DIRECTIONAL INDEX ***********
- Designed by Welles Wilder for commodity daily charts, the ADX is now used in
  several markets by technical traders to judge the strength of a trend.
- The ADX makes use of a positive (+DI) and negative (-DI) directional indicator in
  addition to the trendline.
- The trend has strength when ADX is above 25; the trend is weak or the price is
  trendless when ADX is below 20, according to Wilder.
- Non-trending doesn't mean the price isn't moving. It may not be, but the price
  could also be making a trend change or is too volatile for a clear direction to be present.

ADX formula:
ADX = ((prior ADX * (period - 1)) + current DX) / period

First ADX: sum of DX / period
DX = ((∣+DI − -DI∣)/(∣+DI + -DI∣)) * 100
-DI = (Smoothed -DM / ATR) * 100
+DI = (Smoothed +DM / ATR) * 100
+DM = currHigh - prevHigh > prevLow - currLow => MAX(currHigh - prevHigh; 0); 0)
-DM = prevLow - currLow > currHigh - prevHigh => MAX(prevLow - currLow; 0); 0)
TR = MAX(currHigh - currLow; ∣currHigh - prevClose∣ ; ∣currLow - prevClose∣)
ATR = Average True Range
Smoothed +/-DM = sum of DM / (period - 1) + CDM
CDM = Current DM

Default period: 14
*/

@Injectable()
export class ADXIndicator {
  private _defaultPeriod = 14;

  calculate(id: string, snapshot: IConvertedSnapshotArray, settings?: IIndicatorSettings): ISnapshotIndicator {
    const { highPrices, lowPrices, closePrices } = snapshot;
    let prevADXs: IADXResult[] = [];
    snapshot.indicators.forEach(snapshot => {
      const prevADX = snapshot.find(indicator => indicator.id === id);
      if (prevADX) prevADXs.push(prevADX as IADXResult);
    });
    const period = settings && settings.period ? settings.period : this._defaultPeriod;

    // set return values as empty array if not enough data points
    let calculatedADX: IADXResult = { 
      value: NaN,
      supportValues: {
        ATR: NaN,
        AnDM: NaN,
        ApDM: NaN
      }
    };

    // calculate ADX from prevValue if prevADXs
    if (prevADXs && prevADXs.length > 0) calculatedADX = this.calculatePoint(highPrices, lowPrices, closePrices[closePrices.length - 2], prevADXs[prevADXs.length - 1], period);

    // calculate ADX for all highPrices if length of closingPrices is bigger than 2 x period
    else if (highPrices.length > period * 2) {
        const startIndex = period * 2 - 1;
        for (let i = startIndex; i < highPrices.length; i++) {
          if (i === startIndex) prevADXs = [this.calculateFirstPoint(highPrices.slice(0, i + 1), lowPrices.slice(0, i + 1), closePrices.slice(0, i + 1), period)];
          else prevADXs = [
            ...prevADXs,
            this.calculatePoint(highPrices, lowPrices, closePrices[closePrices.length - 2], prevADXs[prevADXs.length - 1], period)
          ];
        }

        calculatedADX = prevADXs[prevADXs.length - 1];
      }

    return {
      id,
      ...calculatedADX
    };
  }

  private calculatePoint(highPrices: number[], lowPrices: number[], prevClose: number, prevADX: IADXResult, period: number): IADXResult {
    const pDM = this.calculatePositionDM(
      highPrices[highPrices.length - 1], highPrices[highPrices.length - 2],
      lowPrices[lowPrices.length - 1], lowPrices[lowPrices.length - 2]
    );
    const nDM = this.calculateNegativeDM(
      highPrices[highPrices.length - 1], highPrices[highPrices.length - 2],
      lowPrices[lowPrices.length - 1], lowPrices[lowPrices.length - 2]
    );
    const TR = this.calculateTR(highPrices[highPrices.length - 1], lowPrices[lowPrices.length - 1], prevClose);
    const ATR = this.calculateAvgValueOverPeriod([TR], period, prevADX?.supportValues?.ATR);
    const ApDM = this.calculateAvgValueOverPeriod([pDM], period, prevADX?.supportValues?.ApDM);
    const AnDM = this.calculateAvgValueOverPeriod([nDM], period, prevADX?.supportValues?.AnDM);
    const pDI = this.calculateDI(ApDM, ATR);
    const nDI = this.calculateDI(AnDM, ATR);
    const DMI = this.calculateDMI(pDI, nDI);
    const ADX = Math.round(this.calculateAvgValueOverPeriod([DMI], period, prevADX.value) * 100) / 100;

    return { 
      value: ADX, 
      supportValues: { 
        ATR, 
        AnDM, 
        ApDM 
      }
    };
  }

  private calculateFirstPoint(highPrices: number[], lowPrices: number[], closePrices: number[], period: number): IADXResult {
    const pDMs: number[] = [];
    const nDMs: number[] = [];
    const TRs: number[] = [];

    // calculate arrays of pDM, nDM and TR by iterating price arrays, start at index 1
    for (let i = 1; i < highPrices.length; i++) {
      pDMs.push(this.calculatePositionDM(highPrices[i], highPrices[i - 1], lowPrices[i], lowPrices[i - 1]));
      nDMs.push(this.calculateNegativeDM(highPrices[i], highPrices[i - 1], lowPrices[i], lowPrices[i - 1]));
      TRs.push(this.calculateTR(highPrices[i], lowPrices[i], closePrices[i - 1]));
    }

    // calculate array of DMIs by iterating pDM, nDM and TR
    const DMIs: number[] = [];
    const startIndex = period - 1;
    let prevATR = 0;
    let prevApDM = 0;
    let prevAnDM = 0;
    for (let i = startIndex; i < pDMs.length; i++) {
      prevATR = this.calculateAvgValueOverPeriod(TRs.slice(i - startIndex, i + 1), period, i === startIndex ? undefined : prevATR);
      prevApDM = this.calculateAvgValueOverPeriod(pDMs.slice(i - startIndex, i + 1), period, i === startIndex ? undefined : prevApDM);
      prevAnDM = this.calculateAvgValueOverPeriod(nDMs.slice(i - startIndex, i + 1), period, i === startIndex ? undefined : prevAnDM);
      const pDI = this.calculateDI(prevApDM, prevATR);
      const nDI = this.calculateDI(prevAnDM, prevATR);
      DMIs.push(this.calculateDMI(pDI, nDI));
    }

    return {
      value: Math.round(this.calculateAvgValueOverPeriod(DMIs, period) * 100 ) / 100,
      supportValues: {
        ATR: prevATR,
        AnDM: prevAnDM,
        ApDM: prevApDM
      }
    };
  }

  private calculatePositionDM(currHigh: number, prevHigh: number, currLow: number, prevLow: number): number {
    return currHigh - prevHigh > prevLow - currLow ? Math.max(currHigh - prevHigh, 0) : 0;
  }

  private calculateNegativeDM(currHigh: number, prevHigh: number, currLow: number, prevLow: number): number {
    return prevLow - currLow > currHigh - prevHigh ? Math.max(prevLow - currLow, 0) : 0;
  }

  private calculateTR(currHigh: number, currLow: number, prevClose: number): number {
    return Math.max(currHigh - currLow, Math.abs(currHigh - prevClose), Math.abs(currLow - prevClose));
  }

  private calculateAvgValueOverPeriod(arr: number[], period: number, prevValue?: number): number {
    if (prevValue) {
      return (prevValue * (period - 1) + arr[arr.length - 1]) / period;
    } else {
      // calculate first value
      return arr.reduce((a, b) => a + b, 0) / period;
    }
  }

  private calculateDI(ADM: number, ATR: number): number {
    return (ADM / ATR) * 100;
  }

  private calculateDMI(positiveDI: number, negativeDI: number): number {
    return (Math.abs(positiveDI - negativeDI) / Math.abs(positiveDI + negativeDI)) * 100;
  }
}
