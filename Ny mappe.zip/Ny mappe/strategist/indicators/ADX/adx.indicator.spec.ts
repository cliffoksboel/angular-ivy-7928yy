import { ADXIndicator } from './adx.indicator';
import { IADXOutput } from '@project-zero/models';

describe('ADX Indicator', () => {
  let indicator: ADXIndicator;

  beforeEach(() => {
    indicator = new ADXIndicator();
  });

  describe('calculate', () => {
    it('should return an empty array', async () => {
      const expectedResult: IADXOutput[] = [];
      const highPrices = [30.20, 30.28, 30.45, 29.35, 29.35, 29.29, 28.83, 28.73, 28.67, 28.85, 28.64, 27.68, 27.21, 26.87, 27.41, 26.94, 26.52, 26.52, 27.09, 27.69, 28.45, 28.53, 28.67, 29.01, 29.87, 29.80, 29.75];
      const lowPrices = [29.41, 29.32, 29.96, 28.74, 28.56, 28.41, 28.08, 27.43, 27.66, 27.83, 27.40, 27.09, 26.18, 26.13, 26.63, 26.13, 25.43, 25.35, 25.88, 26.96, 27.14, 28.01, 27.88, 27.99, 28.76, 29.14, 28.71];
      const closePrices = [29.87, 30.24, 30.10, 28.90, 28.92, 28.48, 28.56, 27.56, 28.47, 28.28, 27.49, 27.23, 26.35, 26.33, 27.03, 26.22, 26.01, 25.46, 27.03, 27.45, 28.36, 28.43, 27.95, 29.01, 29.38, 29.36, 28.91];
      expect(indicator.calculate({ highPrices, lowPrices, closePrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 2 exact values', async () => {
      const expectedResult: IADXOutput[] = [
        { value: 33.71, supportValues: {
          ATR: 1.0255830697088992,
          ApDM: 0.24324970922341557,
          AnDM: 0.18579660372038118
        }},
        { value: 32.26, supportValues: {
          ATR: 0.9937557075868348,
          ApDM: 0.2258747299931716,
          AnDM: 0.17252541774035393
        }}
      ];
      const highPrices = [30.20, 30.28, 30.45, 29.35, 29.35, 29.29, 28.83, 28.73, 28.67, 28.85, 28.64, 27.68, 27.21, 26.87, 27.41, 26.94, 26.52, 26.52, 27.09, 27.69, 28.45, 28.53, 28.67, 29.01, 29.87, 29.80, 29.75, 30.65, 30.60];
      const lowPrices = [29.41, 29.32, 29.96, 28.74, 28.56, 28.41, 28.08, 27.43, 27.66, 27.83, 27.40, 27.09, 26.18, 26.13, 26.63, 26.13, 25.43, 25.35, 25.88, 26.96, 27.14, 28.01, 27.88, 27.99, 28.76, 29.14, 28.71, 28.93, 30.03];
      const closePrices = [29.87, 30.24, 30.10, 28.90, 28.92, 28.48, 28.56, 27.56, 28.47, 28.28, 27.49, 27.23, 26.35, 26.33, 27.03, 26.22, 26.01, 25.46, 27.03, 27.45, 28.36, 28.43, 27.95, 29.01, 29.38, 29.36, 28.91, 30.61, 30.05];
      expect(indicator.calculate({ highPrices, lowPrices, closePrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 3 exact values', async () => {
      const expectedResult: IADXOutput[] = [
        { value: 33.71, supportValues: {
          ATR: 1.0255830697088992,
          ApDM: 0.24324970922341557,
          AnDM: 0.18579660372038118
        }},
        { value: 32.26, supportValues: {
          ATR: 0.9937557075868348,
          ApDM: 0.2258747299931716,
          AnDM: 0.17252541774035393
        }},
        { value: 30.02, supportValues: {
          ATR: 1.020630299902061,
          ApDM: 0.20974082070794506,
          AnDM: 0.20591645933032868
        }}
      ];
      const highPrices = [30.20, 30.28, 30.45, 29.35, 29.35, 29.29, 28.83, 28.73, 28.67, 28.85, 28.64, 27.68, 27.21, 26.87, 27.41, 26.94, 26.52, 26.52, 27.09, 27.69, 28.45, 28.53, 28.67, 29.01, 29.87, 29.80, 29.75, 30.65, 30.60, 30.76];
      const lowPrices = [29.41, 29.32, 29.96, 28.74, 28.56, 28.41, 28.08, 27.43, 27.66, 27.83, 27.40, 27.09, 26.18, 26.13, 26.63, 26.13, 25.43, 25.35, 25.88, 26.96, 27.14, 28.01, 27.88, 27.99, 28.76, 29.14, 28.71, 28.93, 30.03, 29.39];
      const closePrices = [29.87, 30.24, 30.10, 28.90, 28.92, 28.48, 28.56, 27.56, 28.47, 28.28, 27.49, 27.23, 26.35, 26.33, 27.03, 26.22, 26.01, 25.46, 27.03, 27.45, 28.36, 28.43, 27.95, 29.01, 29.38, 29.36, 28.91, 30.61, 30.05, 30.19];
      const prevADXs = expectedResult.slice(0, expectedResult.length - 1);
      expect(indicator.calculate({ highPrices, lowPrices, closePrices, prevADXs })).toStrictEqual(expectedResult);
    });
  });
});
