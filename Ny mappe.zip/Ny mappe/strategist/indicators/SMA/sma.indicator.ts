import { Injectable } from "@nestjs/common";
import { ISnapshotIndicator, IIndicatorSettings, ISMAResult } from "@project-zero/models";
import { IConvertedSnapshotArray } from "../../models";

/*
*********** SIMPLE MOVING AVERAGE ***********
- Simple moving averages calculate the average of a range of prices
  by the number of periods within that range.
- A simple moving average is a technical indicator that can aid in
  determining if an asset price will continue or if it will reverse a bull or bear trend.
- A simple moving average can be enhanced as an exponential moving average
  (EMA) that is more heavily weighted on recent price action.

SMA formula: (P1 + P2 … Pn) / n
P = closing price-point
n = period
*/

@Injectable()
export class SMAIndicator {
  private _defaultPeriod = 20;
  calculate(id: string, snapshot: IConvertedSnapshotArray, settings?: IIndicatorSettings): ISnapshotIndicator {
    const { closePrices } = snapshot;
    let prevSMAs: ISMAResult[] = [];
    snapshot.indicators.forEach(snapshot => {
      const prevSMA = snapshot.find(indicator => indicator.id === id);
      if (prevSMA) prevSMAs.push(prevSMA as ISMAResult);
    });
    const period = settings && settings.period ? settings.period : this._defaultPeriod;

    // set return values as empty array if not enough data points
    let calculatedSMA: ISMAResult = { value: NaN };

    // calculate sma for one point if prevSMAs
    if (prevSMAs) calculatedSMA = this.calculateSMAPoint(closePrices.slice(closePrices.length - period))

    // initialize sma array if length of closingPrices is or equal to period
    else if (closePrices.length >= period) {
      // calculate sma for all closingPrices - period
      const startIndex = period - 1;
      for (let i = startIndex; i < closePrices.length; i++) {
        prevSMAs = [
          ...prevSMAs,
          this.calculateSMAPoint(closePrices.slice(i - startIndex, i + 1))
        ];
      }

      calculatedSMA = prevSMAs[prevSMAs.length - 1];
    }

    return {
      id,
      ...calculatedSMA
    };
  }

  /* returns average of number array rounded to 5 decimals */
  private calculateSMAPoint(closingPrices: number[]): ISMAResult {
    const total = closingPrices.reduce((a, b) => a + b, 0);
    return {
      value: Math.round((total / closingPrices.length) * 100000) / 100000
    }
  }
}
