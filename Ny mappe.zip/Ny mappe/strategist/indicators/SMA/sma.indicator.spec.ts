import { IIndicatorOutput } from '@project-zero/models';
import { SMAIndicator } from './sma.indicator';

describe('SMA Indicator', () => {
  let indicator: SMAIndicator;

  beforeEach(() => {
    indicator = new SMAIndicator();
  });

  describe('calculate', () => {
    it('should return an empty array', async () => {
      const expectedResult: IIndicatorOutput[] = [];
      const period = 10;
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02];
      expect(indicator.calculate({ closePrices }, { period })).toStrictEqual(expectedResult);
    });

    it('should return an array of 2 exact values', async () => {
      const expectedResult: IIndicatorOutput[] = [
        { value: 112.65000 },
        { value: 111.71300 }
      ];
      const period = 10;
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02, 112.62, 98.50];
      expect(indicator.calculate({ closePrices }, { period })).toStrictEqual(expectedResult);
    });

    it('should return an array of 3 exact values', async () => {
      const expectedResult: IIndicatorOutput[] = [
        { value: 112.65000 },
        { value: 111.71300 },
        { value: 109.83800 }
      ];
      const period = 10;
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02, 112.62, 98.50, 93.50];
      const prevSMAs = expectedResult.slice(0, 2);
      expect(indicator.calculate({ closePrices, prevSMAs }, { period })).toStrictEqual(expectedResult);
    });
  });
});
