import { Injectable } from "@nestjs/common";
import { ISnapshotIndicator, IIndicatorSettings, IEMAResult, ISMAResult } from "@project-zero/models";
import { SMAIndicator } from "../SMA/sma.indicator";
import { IConvertedSnapshotArray } from "../../models";

/*
*********** EXPONENTIAL MOVING AVERAGE ***********
- The EMA is a moving average that places a greater weight and significance on the most recent data points.
- Like all moving averages, this technical indicator is used to produce buy and sell signals based on crossovers and divergences from the historical average.
- Traders often use several different EMA lengths, such as 10-day, 50-day, and 200-day moving averages.
- EMA is a lagging indicator

EMA formula: (P - prevEMA) * (2 / (1 + n) + prevEMA
P = latest closing price-point
prevEMA = previous EMA
n = period

OBS!!! first EMA point is a SMA point because there is no previous EMA
*/

@Injectable()
export class EMAIndicator {
  private _defaultPeriod = 20;
  private _smaService = new SMAIndicator();

  calculate(id: string, snapshot: IConvertedSnapshotArray, settings: IIndicatorSettings): ISnapshotIndicator {
    const { closePrices } = snapshot;
    const prevEMAs: IEMAResult[] = [];
    snapshot.indicators.forEach(snapshot => {
      const prevEMA = snapshot.find(indicator => indicator.id === id);
      if (prevEMA) prevEMAs.push(prevEMA as IEMAResult);
    });
    const period = settings.period ? settings.period : this._defaultPeriod;

    // set return values as empty array if not enough data points
    let calculatedEMA: IEMAResult = { value: NaN };

    // calculate ema from prevValue if prevEMAs
    if (prevEMAs) calculatedEMA = this.calculateEMAPoint(closePrices[closePrices.length - 1], prevEMAs[prevEMAs.length - 1].value, period)

    // calculate ema for all closingPrices - period if length og closingPrices is bigger than period, increase with period + i
    else if (closePrices.length >= period) {
      const calculatedEMAs = this.calculateArray(snapshot, settings);
      calculatedEMA = calculatedEMAs[calculatedEMAs.length - 1];
    }

    return {
      id,
      ...calculatedEMA
    };
  }

  calculateArray(snapshot: IConvertedSnapshotArray, settings: IIndicatorSettings): IEMAResult[] {
    const { closePrices } = snapshot;
    const period = settings.period ? settings.period : this._defaultPeriod;

    // set return values as empty array if not enough data points
    let calculatedEMAs: IEMAResult[] = [];

    // calculate ema for all closingPrices - period if length og closingPrices is bigger than period, increase with period + i
    for (let i = period - 1; i < closePrices.length; i++) {
      if (i === period - 1) calculatedEMAs = [this._smaService.calculate(`SMA-${period}`, { ...snapshot, closePrices: closePrices.slice(0, period) }, settings) as ISMAResult];
      else calculatedEMAs = [
        ...calculatedEMAs,
        this.calculateEMAPoint(closePrices[i], calculatedEMAs[calculatedEMAs.length - 1].value, period)
      ];
    }

    return calculatedEMAs;
  }

  /* returns calculated EMA point rounded to 5 decimals */
  private calculateEMAPoint(closePrice: number, prevEMA: number, period: number): IEMAResult {
    return {
      value: Math.round(((closePrice - prevEMA) * (2 / (1 + period)) + prevEMA) * 100000) / 100000
    }
  }
}
