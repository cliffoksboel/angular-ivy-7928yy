import { EMAIndicator } from './ema.indicator';
import { SMAIndicator } from '../SMA/sma.indicator';
import { IIndicatorOutput } from '@project-zero/models';

describe('EMA Indicator', () => {
  let indicator: EMAIndicator;
  let smaIndicator: SMAIndicator;

  beforeEach(() => {
    smaIndicator = new SMAIndicator();
    indicator = new EMAIndicator(smaIndicator);
  });

  describe('calculate', () => {
    it('should return an empty array', async () => {
      const expectedResult: IIndicatorOutput[] = [];
      const period = 10;
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02];
      expect(indicator.calculate({ closePrices }, { period })).toStrictEqual(expectedResult);
    });

    it('should return an array of 2 exact values', async () => {
      const expectedResult: IIndicatorOutput[] = [
        { value: 112.65000 },
        { value: 110.07727 }
      ];
      const period = 10;
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02, 112.62, 98.50];
      expect(indicator.calculate({ closePrices }, { period })).toStrictEqual(expectedResult);
    });

    it('should return an array of 3 exact values', async () => {
      const expectedResult: IIndicatorOutput[] = [
        { value: 112.65000 },
        { value: 110.07727 },
        { value: 107.06322 }
      ];
      const period = 10;
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02, 112.62, 98.50, 93.50];
      const prevEMAs = expectedResult.slice(0, 2);
      expect(indicator.calculate({ closePrices, prevEMAs }, { period })).toStrictEqual(expectedResult);
    });
  });
});
