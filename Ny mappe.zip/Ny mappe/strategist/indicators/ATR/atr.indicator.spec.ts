import { IIndicatorOutput } from '@project-zero/models';
import { TRIndicator } from '../TR/tr.indicator';
import { ATRIndicator } from './atr.indicator';

describe('ATR Indicator', () => {
  let indicator: ATRIndicator;
  let trIndicator: TRIndicator;

  beforeEach(() => {
    trIndicator = new TRIndicator();
    indicator = new ATRIndicator(trIndicator);
  });

  describe('calculate', () => {
    it('should return an empty array', async () => {
      const expectedResult: IIndicatorOutput[] = [];
      const highPrices = [122.12, 124.75, 119.75, 128.25, 128.00, 113.62, 122.31, 117.81, 134.25, 134.94, 119.62, 104.37, 104.75];
      const lowPrices = [102.25, 109.62, 100.94, 99.50, 101.25, 102.00, 105.50, 100.00, 110.25, 110.25, 86.94, 91.62, 80.06];
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02, 112.62, 98.50, 93.50, 85.00];
      expect(indicator.calculate({ highPrices, lowPrices, closePrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 2 exact values', async () => {
      const expectedResult: IIndicatorOutput[] = [
        { value: 22.07929 },
        { value: 21.89791 }
      ];
      const highPrices = [122.12, 124.75, 119.75, 128.25, 128.00, 113.62, 122.31, 117.81, 134.25, 134.94, 119.62, 104.37, 104.75, 116.75, 118.64];
      const lowPrices = [102.25, 109.62, 100.94, 99.50, 101.25, 102.00, 105.50, 100.00, 110.25, 110.25, 86.94, 91.62, 80.06, 83.75, 99.10];
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02, 112.62, 98.50, 93.50, 85.00, 112.00, 99.90];
      expect(indicator.calculate({ highPrices, lowPrices, closePrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 3 exact values', async () => {
      const expectedResult: IIndicatorOutput[] = [
        { value: 22.07929 },
        { value: 21.89791 },
        { value: 21.81592 }
      ];
      const highPrices = [122.12, 124.75, 119.75, 128.25, 128.00, 113.62, 122.31, 117.81, 134.25, 134.94, 119.62, 104.37, 104.75, 116.75, 118.64, 108.40];
      const lowPrices = [102.25, 109.62, 100.94, 99.50, 101.25, 102.00, 105.50, 100.00, 110.25, 110.25, 86.94, 91.62, 80.06, 83.75, 99.10, 87.65];
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02, 112.62, 98.50, 93.50, 85.00, 112.00, 99.90, 96.18];
      const prevATRs = expectedResult.slice(0, expectedResult.length - 1);
      expect(indicator.calculate({ highPrices, lowPrices, closePrices, prevATRs })).toStrictEqual(expectedResult);
    });
  });
});
