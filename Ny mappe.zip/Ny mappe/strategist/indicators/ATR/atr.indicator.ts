import { Injectable } from "@nestjs/common";
import { ISnapshotIndicator, IIndicatorSettings, IATRResult } from "@project-zero/models";
import { TRIndicator } from "../TR/tr.indicator";
import { IConvertedSnapshotArray } from "../../models";

/*
*********** AVERAGE TRUE RANGE ***********
- The average true range (ATR) is a market volatility indicator used in technical analysis.
- It is typically derived from the 14-day simple moving average of a series of true range indicators.
- The ATR was originally developed for use in commodities markets but has since been applied to all types of securities.
- ATR is a lagging indicator

ATR formula: (prevATR * (n - 1) + TR) / n
prevATR = previous ATR
n = period (standard is 14)
TR = True Range

OBS!!! First ATR in series is average of TR in n period: (TR1 + TR2 + … TRn) / n
*/

@Injectable()
export class ATRIndicator {
  private _defaultPeriod = 14;
  private _trService = new TRIndicator()

  calculate(id: string, snapshot: IConvertedSnapshotArray, settings?: IIndicatorSettings): ISnapshotIndicator {
    const { highPrices } = snapshot;
    let prevATRs: IATRResult[] = [];
    snapshot.indicators.forEach(snapshot => {
      const prevATR = snapshot.find(indicator => indicator.id === id);
      if (prevATR) prevATRs.push(prevATR as IATRResult);
    });
    const period = settings && settings.period ? settings.period : this._defaultPeriod;

    // set return values as empty array if not enough data points
    let calculatedATR: IATRResult = { value: NaN };

    // calculate for one point if prevATRs
    if (prevATRs && prevATRs.length > 0) calculatedATR = this.calculatePoint(prevATRs[prevATRs.length - 1].value, this._trService.calculateArray(snapshot)[0].value, period);

    // initiate ATR array if length of price arrays are greater or equal to period
    else if (highPrices.length >= period) {
      // calculate TR values
      const TRs = this._trService.calculateArray(snapshot);

      // iterate arrays and add ATR to array
      const startIndex = period - 1;
      for (let i = startIndex; i < TRs.length; i++) {
        // add first point if i is equal to period - 1
        if (i === startIndex) prevATRs = [this.calculateFirstPoint(TRs.map(tr => tr.value).slice(0, period), period)];
        // otherwise add additional points
        else prevATRs = [
          ...prevATRs,
          this.calculatePoint(prevATRs[prevATRs.length - 1].value, TRs[i].value, period)
        ];
      }

      calculatedATR = prevATRs[prevATRs.length - 1];
    }

    return {
      id,
      ...calculatedATR
    };
  }

  /* Returns ATR value with 5 decimals + is calculated without providing af TR value */
  private calculatePoint(prevATR: number, TR: number, period: number): IATRResult {
    return {
      value: Math.round(((prevATR * (period - 1) + TR) / period) * 100000) / 100000
    }
  }

  private calculateFirstPoint(TRs: number[], period: number): IATRResult {
    return {
      value: Math.round((TRs.reduce((a, b) => a + b, 0) / period) * 100000) / 100000
    }
  }
}
