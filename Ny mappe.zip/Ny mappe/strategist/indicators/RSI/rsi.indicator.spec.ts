import { IIndicatorOutput } from '@project-zero/models';
import { RSIIndicator } from './rsi.indicator';

describe('RSI Indicator', () => {
  let indicator: RSIIndicator;

  beforeEach(() => {
    indicator = new RSIIndicator();
  });

  describe('calculate', () => {
    it('should return an empty array', async () => {
      const expectedResult: IIndicatorOutput[] = [];
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02, 112.62, 98.50, 93.50, 85.00, 112.00];
      expect(indicator.calculate({ closePrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 2 exact values', async () => {
      const expectedResult: IIndicatorOutput[] = [
        { value: 47.37 },
        { value: 44.67 }
      ];
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02, 112.62, 98.50, 93.50, 85.00, 112.00, 99.90, 96.18];
      expect(indicator.calculate({ closePrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 3 exact values', async () => {
      const expectedResult: IIndicatorOutput[] = [
        { value: 47.37 },
        { value: 44.67 },
        { value: 53.87 }
      ];
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02, 112.62, 98.50, 93.50, 85.00, 112.00, 99.90, 96.18, 115.14];
      const prevRSIs = expectedResult.slice(0, 2);
      expect(indicator.calculate({ closePrices, prevRSIs})).toStrictEqual(expectedResult);
    });
  });
});
