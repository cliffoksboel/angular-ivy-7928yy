import { Injectable } from "@nestjs/common";
import { ISnapshotIndicator, IIndicatorSettings, IRSIResult } from "@project-zero/models";
import { IConvertedSnapshotArray } from "../../models";

/*
*********** RELATIVE STRENGTH INDEX ***********
- The relative strength index (RSI) is a popular momentum oscillator introduced in 1978.
- The RSI provides technical traders with signals about bullish and bearish price momentum, and it is often plotted beneath the graph of an asset’s price.
- An asset is usually considered overbought when the RSI is above 70 and oversold when it is below 30.
- The RSI line crossing below the overbought line or above oversold line is often seen by traders as a signal to buy or sell.
- The RSI works best in trading ranges rather than trending markets.
- RSI is a leading indicator

RSI formula: 100 - (100 / (1 + RS))
RS = Relative Strength

RS formula: avgGain / avgLoss
avgGain = Average Gain over specified period
avgLoss = Average loss over the same period

Gain/Loss = close - prevClose
avgGain: sum(gains) / period
avgLoss: sum(losses) / period

OBS!!! If Average Loss equals zero, a "divide by zero" situation occurs for RS and RSI
is set to 100 by definition. Similarly, RSI equals 0 when Average Gain equals zero.
*/

@Injectable()
export class RSIIndicator {
  private _defaultPeriod = 14;

  calculate(id: string, snapshot: IConvertedSnapshotArray, settings?: IIndicatorSettings): ISnapshotIndicator {
    const { closePrices } = snapshot;
    const prevRSIs: IRSIResult[] = [];
    snapshot.indicators.forEach(snapshot => {
      const prevRSI = snapshot.find(indicator => indicator.id === id);
      if (prevRSI) prevRSIs.push(prevRSI as IRSIResult);
    });
    const period = settings && settings.period ? settings.period : this._defaultPeriod;

    // set return values as empty array if not enough data points
    let calculatedRSI: IRSIResult = { value: NaN };

    // calculate RSI for one point if prevRSIs are provided
    if (prevRSIs) calculatedRSI = this.calculatePoint(period, closePrices.slice(-(period + 1)));

    // calculate RSI recursively if length of closing prices are greater than period
    else if (closePrices.length > period) {
      const calculatedRSIs = this.calculateSeries(period, closePrices);
      calculatedRSI = calculatedRSIs[calculatedRSIs.length - 1];
    }

    return {
      id,
      ...calculatedRSI
    };
  }

  calculateArray(snapshot: IConvertedSnapshotArray, settings?: IIndicatorSettings): IRSIResult[] {
    const { closePrices } = snapshot;
    const period = settings && settings.period ? settings.period : this._defaultPeriod;

    return this.calculateSeries(period, closePrices);
  }

  private calculatePoint(period: number, closePrices: number[]): IRSIResult {
    /* Calculate total gains and losses */
    let totalGain = 0;
    let totalLoss = 0;

    for (let i = 1; i < closePrices.length; i++) {
      /* Calculate changes in closing prices */
      const change = closePrices[i] - closePrices[i - 1];
      /* Change is positive */
      if (change > 0) totalGain += change;
      /* Change is negative */
      if (change < 0) totalLoss += Math.abs(change);
    }

    /* Check if totalGains or totalLosses are zero */
    if (totalGain === 0) return { value: 0 };
    if (totalLoss === 0) return { value: 100 };

    /* Calculate RS and return as index (RSI) */
    const avgGain = totalGain / period;
    const avgLoss = totalLoss / period;
    const RS = avgGain / avgLoss;
    return {
      value: Math.round((100 - (100 / (1 + RS))) * 100) / 100
    }
  }

  private calculateSeries(period: number, closePrices: number[]): IRSIResult[] {
    /* Exit-case for recursive loop */
    if (closePrices.length === period) return [];

    /* Calculate RSI in array recursively */
    return [
      this.calculatePoint(period, closePrices.slice(0, period + 1)),
      ...this.calculateSeries(period, closePrices.slice(1))
    ];
  }
}
