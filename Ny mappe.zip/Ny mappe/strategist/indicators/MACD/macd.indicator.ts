import { Injectable } from "@nestjs/common";
import { ISnapshotIndicator, IIndicatorSettings, IMACDResult } from "@project-zero/models";
import { EMAIndicator } from "../EMA/ema.indicator";
import { IConvertedSnapshotArray } from "../../models";

/*
*********** MOVING AVERAGE CONVERGENCE/DIVERGENCE ***********
- The moving average convergence/divergence (MACD, or MAC-D) line is calculated by subtracting the 26-period
  exponential moving average (EMA) from the 12-period EMA. The signal line is a nine-period EMA of the MACD line.
- MACD is best used with daily periods, where the traditional settings of 26/12/9 days is the norm.
- MACD triggers technical signals when the MACD line crosses above the signal line (to buy) or falls below it (to sell).
- MACD can help gauge whether a security is overbought or oversold, alerting traders to the strength of a directional
  move, and warning of a potential price reversal.
- MACD can also alert investors to bullish/bearish divergences (e.g., when a new high in price is not confirmed by a
  new high in MACD, and vice versa), suggesting a potential failure and reversal.
- After a signal line crossover, it is recommended to wait for three or four days to confirm that it is not a false move.

MACD formula: EMA(12) - EMA(26)
Signal formula: 9-priod EMA of MACD
Histogram formula: MACD - Signal
*/

@Injectable()
export class MACDIndicator {
  private _fastEmaPeriod = 12;
  private _slowEmaPeriod = 26;
  private _signalPeriod = 9;
  private _emaService = new EMAIndicator();

  calculate(id: string, snapshot: IConvertedSnapshotArray, settings?: IIndicatorSettings): ISnapshotIndicator {
    const { closePrices } = snapshot;
    let prevMACDs: IMACDResult[] = [];
    snapshot.indicators.forEach(snapshot => {
      const prevMACD = snapshot.find(indicator => indicator.id === id);
      if (prevMACD) prevMACDs.push(prevMACD as IMACDResult);
    });
    const fastEmaPeriod = settings && settings.fastEMAPeriod ? settings.fastEMAPeriod : this._fastEmaPeriod;
    const slowEmaPeriod = settings && settings.slowEMAPeriod ? settings.slowEMAPeriod : this._slowEmaPeriod;
    const signalPeriod = settings && settings.signalLinePeriod ? settings.signalLinePeriod : this._signalPeriod;

    // set return values as empty array if not enough data points
    let calculatedMACD: IMACDResult = { 
      valueMACD: NaN,
      valueMACDSignal: NaN,
      valueMACDHistogram: NaN,
      supportValues: {
        fastEma: NaN,
        slowEma: NaN
      }
    };

    // calculate MACD from prevValue if prevMACDs
    if (prevMACDs) calculatedMACD = this.calculatePoint(snapshot, closePrices[closePrices.length - 1], prevMACDs[prevMACDs.length - 1], fastEmaPeriod, slowEmaPeriod, signalPeriod)

    // calculate MACD for all closingPrices - (emaLongPeriod + signalPeriod) if length of closingPrices is bigger or equal than (emaLongPeriod + signalPeriod)
    else {
      const totalPeriod = slowEmaPeriod + signalPeriod - 1;
      if (closePrices.length >= totalPeriod) {
        for (let i = totalPeriod - 1; i < closePrices.length; i++) {
          if (i === totalPeriod - 1) prevMACDs = [
            this.calculateFirstPoint(snapshot, closePrices.slice(0, totalPeriod), fastEmaPeriod, slowEmaPeriod, signalPeriod)
          ];
          else prevMACDs = [
            ...prevMACDs,
            this.calculatePoint(snapshot, closePrices[i], prevMACDs[prevMACDs.length - 1], fastEmaPeriod, slowEmaPeriod, signalPeriod)
          ];
        }

        calculatedMACD = prevMACDs[prevMACDs.length - 1];
      }
    }


    return {
      id,
      ...calculatedMACD
    };
  }

  private calculatePoint(snapshot: IConvertedSnapshotArray, closePrice: number, prevMACD: IMACDResult, fastEmaPeriod: number, slowEmaPeriod: number, signalPeriod: number): IMACDResult {
    // calculate EMA values
    const fastEma = this._emaService.calculate(
      `EMA-${fastEmaPeriod}`,
      {
        ...snapshot,
        closePrices: [closePrice],
        indicators: [[{ 
          id: `EMA-${fastEmaPeriod}`, 
          value: prevMACD.supportValues.fastEma 
        }]]
      },
      { period: fastEmaPeriod }
    ).value!;
    const slowEma = this._emaService.calculate(
      `EMA-${slowEmaPeriod}`,
      {
        ...snapshot,
        closePrices: [closePrice],
        indicators: [[{ 
          id: `EMA-${slowEmaPeriod}`, 
          value: prevMACD.supportValues.slowEma 
        }]]
      },
      { period: slowEmaPeriod }
    ).value!;

    // calculate MACD
    const valueMACD = this.calculateMACD(fastEma, slowEma);

    // calculate signal from EMA of MACD
    const valueMACDSignal = this._emaService.calculate(
      `EMA-${signalPeriod}`,
      {
        ...snapshot,
        closePrices: [valueMACD],
        indicators: [[{
          id: `EMA-${signalPeriod}`,
          value: prevMACD.valueMACDSignal
        }]]
      },
      { period: signalPeriod }
    ).value!;

    // calculate histogram
    const valueMACDHistogram = this.calculateHistogram(valueMACD, valueMACDSignal);

    return {
      valueMACD,
      valueMACDSignal,
      valueMACDHistogram,
      supportValues: {
        fastEma,
        slowEma
      }
    }
  }

  private calculateFirstPoint(snapshot: IConvertedSnapshotArray, closePrices: number[], fastEmaPeriod: number, slowEmaPeriod: number, signalPeriod: number): IMACDResult {
    // calculate EMA values
    const fastEmas = this._emaService.calculateArray(
      {
        ...snapshot,
        closePrices,
        indicators: []
      },
      { period: fastEmaPeriod }
    );
    const slowEmas = this._emaService.calculateArray(
      {
        ...snapshot,
        closePrices,
        indicators: []
      },
      { period: slowEmaPeriod }
    );

    // calculate MACD
    let macds: number [] = [];
    for (let i = 0; i < slowEmas.length; i++) {
      macds = [
        ...macds,
        this.calculateMACD(fastEmas[i + (slowEmaPeriod - fastEmaPeriod)].value, slowEmas[i].value)
      ];
    }

    // calculate signal from EMA of MACD
    const valueMACDSignal = this._emaService.calculate(
      'EMA',
      {
        ...snapshot,
        closePrices: macds,
        indicators: []
      },
      { period: signalPeriod }
    ).value!;

    // calculate histogram
    const valueMACDHistogram = this.calculateHistogram(macds[macds.length - 1], valueMACDSignal);

    return {
      valueMACD: macds[macds.length - 1],
      valueMACDSignal,
      valueMACDHistogram,
      supportValues: {
        fastEma: fastEmas[fastEmas.length - 1].value,
        slowEma: slowEmas[slowEmas.length - 1].value
      }
    }
  }

  private calculateMACD(emaShort: number, emaLong: number): number {
    return Math.round((emaShort - emaLong) * 100000) / 100000;
  }

  private calculateHistogram(macd: number, signal: number): number {
    return Math.round((macd - signal) * 100000) / 100000;
  }
}
