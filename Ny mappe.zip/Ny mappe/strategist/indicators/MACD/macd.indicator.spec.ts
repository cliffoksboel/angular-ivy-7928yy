import { MACDIndicator } from './macd.indicator';
import { SMAIndicator } from '../SMA/sma.indicator';
import { EMAIndicator } from '../EMA/ema.indicator';
import { IMACDOutput } from '@project-zero/models';

describe('EMA Indicator', () => {
  let indicator: MACDIndicator;
  let emaIndicator: EMAIndicator;
  let smaIndicator: SMAIndicator;

  beforeEach(() => {
    smaIndicator = new SMAIndicator();
    emaIndicator = new EMAIndicator(smaIndicator);
    indicator = new MACDIndicator(emaIndicator);
  });

  describe('calculate', () => {
    it('should return an empty array', async () => {
      const expectedResult: IMACDOutput[] = [];
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02, 112.62, 98.50, 93.50, 85.00, 112.00, 99.90, 96.18, 115.14, 111.80, 113.50, 105.21, 99.95, 91.72, 108.07, 115.59, 120.96, 107.89, 98.12, 104.00, 83.76, 80.45, 72.00, 70.40, 75.38];
      expect(indicator.calculate({ closePrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 2 exact values', async () => {
      const expectedResult: IMACDOutput[] = [
        { macd: -9.84548, signal: -4.03905, histogram: -5.80643, supportValues: { fastEma: 84.25902, slowEma: 94.10450 }},
        { macd: -9.54049, signal: -5.13934, histogram: -4.40115, supportValues: { fastEma: 83.44071, slowEma: 92.98120 }}
      ];
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02, 112.62, 98.50, 93.50, 85.00, 112.00, 99.90, 96.18, 115.14, 111.80, 113.50, 105.21, 99.95, 91.72, 108.07, 115.59, 120.96, 107.89, 98.12, 104.00, 83.76, 80.45, 72.00, 70.40, 75.38, 58.31, 78.94];
      expect(indicator.calculate({ closePrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 3 exact values', async () => {
      const expectedResult: IMACDOutput[] = [
        { macd: -9.84549, signal: -4.03905, histogram: -5.80643, supportValues: { fastEma: 84.25902, slowEma: 94.10450 }},
        { macd: -9.54050, signal: -5.13934, histogram: -4.40116, supportValues: { fastEma: 83.44071, slowEma: 92.98120 }},
        { macd: -8.55623, signal: -5.82272, histogram: -2.73351, supportValues: { fastEma: 83.97599, slowEma: 92.53222 }}
      ];
      const closePrices = [107.87, 112.25, 102.75, 118.37, 111.50, 107.31, 109.56, 112.25, 132.02, 112.62, 98.50, 93.50, 85.00, 112.00, 99.90, 96.18, 115.14, 111.80, 113.50, 105.21, 99.95, 91.72, 108.07, 115.59, 120.96, 107.89, 98.12, 104.00, 83.76, 80.45, 72.00, 70.40, 75.38, 58.31, 78.94, 86.92];
      const prevMACDs = expectedResult.slice(0, 2);
      expect(indicator.calculate({ closePrices, prevMACDs })).toStrictEqual(expectedResult);
    });
  });
});
