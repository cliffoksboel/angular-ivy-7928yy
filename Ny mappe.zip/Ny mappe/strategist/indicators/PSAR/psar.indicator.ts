import { Injectable } from "@nestjs/common";
import { ISnapshotIndicator, IIndicatorSettings, IndicatorTrend, IPSARResult } from "@project-zero/models";
import { IConvertedSnapshotArray } from "../../models";

/*
*********** PARABOLIC STOP AND REVERSE ***********
- The parabolic SAR (stop and reverse) indicator is used by technical traders to spot trends and reversals.
- The indicator utilizes a system of dots superimposed onto a price chart.
- A reversal occurs when these dots flip, but a reversal signal in the SAR does not necessarily mean a reversal in the price. A PSAR reversal only means that the price and indicator have crossed
- PSAR is a leading indicator

PSAR formula:
RPSAR = Prior PSAR + [Prior AF(Prior EP - Prior PSAR)]
FPSAR = Prior PSAR − [Prior AF(Prior PSAR - Prior EP)]

RPSAR = Rising PSAR
FPSAR = Falling PSAR
AF = Acceleration Factor, it starts at 0.02 and
increases by 0.02, up to a maximum of 0.2, each
time the extreme point makes a new low (falling
SAR) or high(rising SAR)
EP = Extreme Point, the lowest low in the current
downtrend(falling SAR) or the highest high in the
current uptrend(rising SAR)

Initial values:
EP = lowest low or highest high of first 2 data points
AF = 0.02
Trend = If high increases from first to second data point = bull otherwise bear
PSAR = High (if bear) or Low (if bull)

OBS!!! we need at least 3 data-points to initiate. For the first 2 data-points PSAR, EP and AF is not calculated.
The first 2 data-points are used tp make a best guess on the third data-point.
PSAR will correct it self after min 5 periods.
*/

@Injectable()
export class PSARIndicator {
  private _initialAcceleration = 0.02;
  private _accelerationStep = 0.02;
  private _accelerationLimit = 0.2;
  private _minArrayLength = 3;

  calculate(id: string, snapshot: IConvertedSnapshotArray, settings?: IIndicatorSettings): ISnapshotIndicator {
    const { highPrices, lowPrices } = snapshot;
    let prevPSARs: IPSARResult[] = [];
    snapshot.indicators.forEach(snapshot => {
      const prevPSAR = snapshot.find(indicator => indicator.id === id);
      if (prevPSAR) prevPSARs.push(prevPSAR as IPSARResult);
    });
    const initialAcceleration = settings && settings.initialAcceleration ? settings.initialAcceleration : this._initialAcceleration;
    const accelerationStep = settings && settings.accelerationStep ? settings.accelerationStep : this._accelerationStep;
    const accelerationLimit = settings && settings.accelerationLimit ? settings.accelerationLimit : this._accelerationLimit;

    // set return values as empty array if not enough data points
    let calculatedPSAR: IPSARResult = { 
      valuePSAR: NaN,
      valuePSARTrend: IndicatorTrend.BULL,
      supportValues: {
        ep: NaN,
        af: NaN
      }
    };

    // calculate PSAR for one point id prevPSAR
    if (prevPSARs) calculatedPSAR = this.calculatePoint(highPrices.slice(-3), lowPrices.slice(-3), prevPSARs[prevPSARs.length - 1], initialAcceleration, accelerationStep, accelerationLimit);

    // initiate new PSAR array if length of price arrays are greater og equal to 3
    else if (highPrices.length > this._minArrayLength - 1) {
      // iterate arrays and add PSAR to array
      const startIndex = this._minArrayLength - 1;
      for (let i = startIndex; i < highPrices.length; i++) {
        const firstIndex = i - 2;
        const lastIndex = i + 1;
        // add first point if i is equal to 2
        if (i === startIndex) prevPSARs = [
          this.calculateFirstPoint(highPrices.slice(firstIndex, lastIndex), lowPrices.slice(firstIndex, lastIndex), initialAcceleration)
        ];
        // otherwise add additional points
        else prevPSARs = [
          ...prevPSARs,
          this.calculatePoint(highPrices.slice(firstIndex, lastIndex), lowPrices.slice(firstIndex, lastIndex), prevPSARs[prevPSARs.length - 1], initialAcceleration, accelerationStep, accelerationLimit)
        ];
      }

      calculatedPSAR = prevPSARs[prevPSARs.length - 1];
    }

    return {
      id,
      ...calculatedPSAR
    };
  }

  private calculatePoint(highPrices: number[], lowPrices: number[], prevPSAR: IPSARResult, initialAcceleration: number, accelerationStep: number, accelerationLimit: number): IPSARResult {
    const { valuePSAR, valuePSARTrend } = prevPSAR;
    const ep = prevPSAR.supportValues?.ep as number;
    const af = prevPSAR.supportValues?.af as number;
    const newSAR = this.calculateSARPoint(highPrices, lowPrices, valuePSAR, ep, af, valuePSARTrend);
    const newTREND = this.decideTrendPoint(valuePSARTrend, ep, newSAR);
    const newEP = this.calculateEPPoint(highPrices, lowPrices, ep, valuePSARTrend, newTREND);
    const newAF = this.calculateAFPoint(ep, valuePSARTrend, newTREND, initialAcceleration, accelerationStep, accelerationLimit);
    return {
      valuePSAR: newSAR,
      valuePSARTrend: newTREND,
      supportValues: {
        af: newAF,
        ep: newEP
      }
    };
  }

  private calculateFirstPoint(highPrices: number[], lowPrices: number[], initialAcceleration: number): IPSARResult {
    return {
      valuePSAR: this.calculateSARFirstPoint(highPrices, lowPrices),
      valuePSARTrend: this.decideTrendFirstPoint(highPrices),
      supportValues: {
        ep: this.calculateEPFirstPoint(highPrices, lowPrices),
        af: this.calculateAFFirstPoint(initialAcceleration)
      }
    };
  }

  private calculateSARFirstPoint(highPrices: number[], lowPrices: number[]): number {
    // if high price is increasing from t-2 to t-1 (uptrend) return lowest low
    if (highPrices[highPrices.length - 2] > highPrices[highPrices.length - 3]) {
      return Math.min(lowPrices[lowPrices.length - 2], lowPrices[lowPrices.length - 3]);
    } else {
      // otherwise return highest high
      return Math.max(highPrices[highPrices.length - 2], highPrices[highPrices.length - 3]);
    }
  }

  private calculateSARPoint(highPrices: number[], lowPrices: number[], prevSAR: number, prevEP: number, prevAF: number, prevTrend: IndicatorTrend): number {
    let newSAR: number;

    // set new SAR from lowest low and prev values if prev Trend is Bull
    if (prevTrend === IndicatorTrend.BULL) {
      newSAR = Math.min(lowPrices[lowPrices.length - 2], lowPrices[lowPrices.length - 3], (prevSAR + prevAF * (prevEP - prevSAR)));

      // set to prev EP if new SAR is bigger than current low
      if (newSAR > lowPrices[lowPrices.length - 1]) newSAR = prevEP;
    } else {
      // set new SAR from highest high and prev values if prev Trend is Bear
      newSAR = Math.max(highPrices[highPrices.length - 2], highPrices[highPrices.length - 3], (prevSAR - prevAF * (prevSAR - prevEP)));

      // set to prev EP if new SAR is smaller than current high
      if (newSAR < highPrices[highPrices.length - 1]) newSAR = prevEP;
    }

    return newSAR;
  }

  private decideTrendFirstPoint(highPrices: number[]): IndicatorTrend {
    // return initial trend if no prev Trend and high price is increasing from t-2 to t-1 (uptrend) return bull, otherwise return bear
    return highPrices[highPrices.length - 2] > highPrices[highPrices.length - 3] ? IndicatorTrend.BULL : IndicatorTrend.BEAR;
  }

  private decideTrendPoint(prevTrend: IndicatorTrend, prevEP: number, currSAR: number): IndicatorTrend {
    // return reversed Trend if current PSAR is equal to previous EP
    if (currSAR === prevEP) return prevTrend === IndicatorTrend.BULL ? IndicatorTrend.BEAR : IndicatorTrend.BULL;

    // return prev Trend as default
    return prevTrend;
  }

  private calculateEPFirstPoint(highPrices: number[], lowPrices: number[]): number {
    // return max of highs if high price is increasing from t-2 to t-1 (uptrend)
    if (highPrices[highPrices.length - 2] > highPrices[highPrices.length - 3]) {
      return Math.max(highPrices[highPrices.length - 2], highPrices[highPrices.length - 3]);
    } else {
      // otherwise (downtrend) return min of lows
      return Math.min(lowPrices[lowPrices.length - 2], lowPrices[lowPrices.length - 3]);
    }
  }

  private calculateEPPoint(highPrices: number[], lowPrices: number[], prevEP: number, prevTrend: IndicatorTrend, currTrend: IndicatorTrend): number {
    // return current low (if prevTrend = Bull) or current high (if prevTrend = Bear) if trend is reversing
    if (prevTrend !== currTrend) {
      if (prevTrend === IndicatorTrend.BULL) return lowPrices[lowPrices.length - 1];
      else return highPrices[highPrices.length - 1];
    } else {
      // otherwise return updated EP highest high if prev trend is Bull or lowest low if prev trend is bear
      if (prevTrend === IndicatorTrend.BULL) {
        return Math.max(highPrices[highPrices.length - 1], prevEP);
      } else {
        return Math.min(lowPrices[lowPrices.length - 1], prevEP);
      }
    }
  }

  private calculateAFFirstPoint(initialAcceleration: number): number {
    return initialAcceleration;
  }

  private calculateAFPoint(prevAF: number, prevTrend: IndicatorTrend, currTrend: IndicatorTrend, initialAcceleration: number, accelerationStep: number, accelerationLimit: number): number {
    // return initial AF value if no prev AF or trend is reversing
    if (prevTrend !== currTrend) return initialAcceleration;

    // otherwise return incremented AF, not higher than maxAccFactor
    return Math.min(prevAF + accelerationStep, accelerationLimit);
  }
}
