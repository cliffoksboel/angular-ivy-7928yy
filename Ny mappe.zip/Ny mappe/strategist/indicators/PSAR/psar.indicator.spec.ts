import { IndicatorTrend, IPSAROutput } from '@project-zero/models';
import { PSARIndicator } from './psar.indicator';

describe('PSAR Indicator', () => {
  let indicator: PSARIndicator;

  beforeEach(() => {
    indicator = new PSARIndicator();
  });

  describe('calculate', () => {
    it('should return an empty array', async () => {
      const expectedResult: IPSAROutput[] = [];
      const highPrices = [122.12, 124.75];
      const lowPrices = [102.25, 109.62];
      expect(indicator.calculate({ highPrices, lowPrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 2 exact values', async () => {
      const expectedResult: IPSAROutput[] = [
        { sar: 102.25, trend: IndicatorTrend.BULL, supportValues: { EP: 124.75, AF: 0.02 }},
        { sar: 124.75, trend: IndicatorTrend.BEAR, supportValues: { EP: 99.50, AF: 0.02 }}
      ];
      const highPrices = [122.12, 124.75, 119.75, 128.25];
      const lowPrices = [102.25, 109.62, 100.94, 99.50];
      expect(indicator.calculate({ highPrices, lowPrices })).toStrictEqual(expectedResult);
    });

    it('should return an array of 3 exact values', async () => {
      const expectedResult: IPSAROutput[] = [
        { sar: 102.25, trend: IndicatorTrend.BULL, supportValues: { EP: 124.75, AF: 0.02 }},
        { sar: 124.75, trend: IndicatorTrend.BEAR, supportValues: { EP: 99.50, AF: 0.02 }},
        { sar: 128.25, trend: IndicatorTrend.BEAR, supportValues: { EP: 99.50, AF: 0.04 }}
      ];
      const highPrices = [122.12, 124.75, 119.75, 128.25, 128.00];
      const lowPrices = [102.25, 109.62, 100.94, 99.50, 101.25];
      const prevPSARs = expectedResult.slice(0, expectedResult.length - 1);
      expect(indicator.calculate({ highPrices, lowPrices, prevPSARs })).toStrictEqual(expectedResult);
    });
  });
});
