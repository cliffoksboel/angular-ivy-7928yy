import { Injectable } from "@nestjs/common";
import { ISnapshotIndicator, IIndicatorSettings, IWPRResult } from "@project-zero/models";
import { IConvertedSnapshotArray } from "../../models";

/*
*********** WILLIAMS PERCENT RANGE ***********
- Williams %R moves between zero and -100.
- A reading above -20 is overbought.
- A reading below -80 is oversold.
- An overbought or oversold reading doesn't mean the price will reverse. Overbought
  simply means the price is near the highs of its recent range, and oversold means the
  price is in the lower end of its recent range.
- Can be used to generate trade signals when the price and the indicator move out of
  overbought or oversold territory.

WPR formula: (highest high - close) / (highest high - lowest low) * -100

Highest High = Highest price in the lookback period, typically 14 days.
Close = Most recent closing price.
Lowest Low = Lowest price in the lookback period, typically 14 days.
*/

@Injectable()
export class WPRIndicator {
  private _defaultPeriod = 14;

  calculate(id: string, snapshot: IConvertedSnapshotArray, settings?: IIndicatorSettings): ISnapshotIndicator {
    const { highPrices, lowPrices, closePrices } = snapshot;
    let prevWPRs: IWPRResult[] = [];
    snapshot.indicators.forEach(snapshot => {
      const prevWPR = snapshot.find(indicator => indicator.id === id);
      if (prevWPR) prevWPRs.push(prevWPR as IWPRResult);
    });
    const period = settings && settings.period ? settings.period : this._defaultPeriod;

    // set return values as empty array if not enough data points
    let calculatedWPR: IWPRResult = { value: NaN };

    // calculate WPR for one point if prevWPRs are provided
    if (prevWPRs) calculatedWPR = this.calculateWPRPoint(highPrices.slice(-period), lowPrices.slice(-period), closePrices[closePrices.length - 1])

    // calculate WPR for all prices if length of prices is equal or greater than period
    else if (highPrices.length > period - 1, lowPrices.length > period - 1, closePrices.length > period - 1) {
      const startIndex = period - 1;
      for (let i = startIndex; i < highPrices.length; i++) {
        prevWPRs = [
          ...prevWPRs,
          this.calculateWPRPoint(highPrices.slice(i - startIndex, i + 1), lowPrices.slice(i - startIndex, i + 1), closePrices[i])
        ];
      }

      calculatedWPR = prevWPRs[prevWPRs.length - 1];
    }

    return {
      id,
      ...calculatedWPR
    };
  }

  calculateWPRPoint(highPrices: number[], lowPrices: number[], currClose: number): IWPRResult {
    const highestHigh = Math.max(...highPrices);
    const lowestLow = Math.min(...lowPrices);
    return {
      value: Math.round(((highestHigh - currClose) / (highestHigh - lowestLow) * -100) * 100) / 100
    }
  }
}
