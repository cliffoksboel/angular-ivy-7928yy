import { EventPattern, MessagePattern } from '@nestjs/microservices';
import { Controller } from "@nestjs/common";
import { LabElementService } from "./lab-element.service";
import { CreateLabElementDTO, LabElementDTO, MessageBrokerEnv, MessageBrokerEvent, MessageBrokerMessage, NewSnapshotStreamDataDTO } from '@project-zero/models';

@Controller()
export class LabElementController {
  constructor(private readonly _labElementService: LabElementService) {}

  @MessagePattern({ message: MessageBrokerMessage.CREATE_LAB_ELEMENT, podEnv: MessageBrokerEnv.POD_ENV })
  async createLabElement(createLabElementDTO: CreateLabElementDTO): Promise<LabElementDTO> {
    return await this._labElementService.createLabElement(createLabElementDTO);
  }

  @MessagePattern({ message: MessageBrokerMessage.GET_LAB_ELEMENTS, podEnv: MessageBrokerEnv.POD_ENV })
  async getLabElements(): Promise<LabElementDTO[]> {
    return await this._labElementService.getLabElements();
  }

  @MessagePattern({ message: MessageBrokerMessage.GET_LAB_ELEMENT, podEnv: MessageBrokerEnv.POD_ENV })
  async getLabElement(labElementId: string): Promise<LabElementDTO> {
    return await this._labElementService.getLabElement(labElementId);
  }

  @MessagePattern({ message: MessageBrokerMessage.DELETE_LAB_ELEMENT, podEnv: MessageBrokerEnv.POD_ENV })
  async deleteLabElement(labElementId: string): Promise<LabElementDTO> {
    return await this._labElementService.deleteLabElement(labElementId);
  }

  /* LIVETEST ACTIONS */
  @EventPattern({ event: MessageBrokerEvent.NEW_LIVETEST_SNAPSHOTS_FROM_IG, podEnv: MessageBrokerEnv.POD_ENV })
  livetestSnapshotStream(newStreamSnapshots: NewSnapshotStreamDataDTO[]) {
    this._testActionService.onSnapshotStream(newStreamSnapshots);
  }
}
