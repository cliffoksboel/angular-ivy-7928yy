export const MessageBrokerMessage = {
  /* ACCOUNT */
  GET_ACCOUNT: { message: 'get-account' }, // called from API-GATEWAY
  GET_ALL_ACCOUNTS: { message: 'get-all-accounts' }, // called from API-GATEWAY
  GET_AVAILABLE_ACCOUNTS: { message: 'get-available-accounts' }, // called from API-GATEWAY
  GET_ACCOUNT_DETAILS: { message: 'get-account-details' }, // called from BROKER
  GET_ACCOUNTS_FROM_IG: { message: 'get-accounts-from-ig' }, // called from CORE
  GET_ACCOUNT_FROM_IG: { message: 'get-account-from-ig', env: process.env['ENV'] }, // called from CORE
  GET_ACCOUNT_ACTIVITY_FROM_IG: { message: 'get-account-activity' }, // called from CORE
  GET_ACCOUNT_TRANSACTIONS_FROM_IG: { message: 'get-account-transactions' }, // called from CORE
  
  /* AUTH / USER */
  UPDATE_USER: { message: 'update-user' }, // called from API-GATEWAY
  UPDATE_USER_AVATAR: { message: 'update-user-avatar' }, // called from API-GATEWAY
  DELETE_USER: { message: 'delete-user' }, // called from API-GATEWAY
  GET_ALL_USERS: { message: 'get-all-users' }, // called from API-GATEWAY
  GET_USER: { message: 'get-user' }, // called from API-GATEWAY
  CREATE_USER: { message: 'create-user' }, // called from API-GATEWAY
  GENERATE_PASSWORD: { message: 'generate-password' }, // called from API-GATEWAY
  UPDATE_PASSWORD: { message: 'update-password' }, // called from API-GATEWAY
  LOGIN_USER: { message: 'login-user' }, // called from API-GATEWAY
  
  /* CURRENCY */
  
  /* HEALTH */
  ANALYST_HEALTH_CHECK: { message: 'analyst-health-check' }, // called from CORE, API
  REFRESH_APP_HEALTH: { message: 'refresh-app-health' }, // called by API, CLOUD SCHEDULER
  GET_APP_HEALTH: { message: 'get-app-health' }, // called from API
  IG_API_GATEWAY_HEALTH_CHECK: { message: 'ig-api-gateway-health-check' }, // called from CORE
  IG_STREAMING_GATEWAY_HEALTH_CHECK: { message: 'ig-streaming-gateway-health-check' }, // called from CORE
  API_GATEWAY_HEALTH_CHECK: { message: 'api-gateway-health-check' }, // called from CORE
  
  /* INSTRUMENT */
  GET_INSTRUMENT_BY_NAME: { message: 'get-instrument-by-name' }, // called from ANALYST
  GET_INSTRUMENT_BY_EPIC: { message: 'get-instrument-by-epic' }, // called from ANALYST
  GET_EPIC_DETAILS_FROM_IG: { message: 'get-epic-details-from-ig', env: process.env['ENV'] }, // called from CORE, ANALYST
  GET_MULTIPLE_EPIC_DETAILS_FROM_IG: { message: 'get-multiple-epic-details-from-ig', env: process.env['ENV'] }, // called from CORE
  
  /* LAB-ELEMENT */
  GET_LAB_ELEMENTS: { message: 'get-lab-elements' }, // called from API-GATEWAY
  GET_LAB_ELEMENT: { message: 'get-lab-element' }, // called from API-GATEWAY
  DELETE_LAB_ELEMENT: { message: 'delete-lab-element' }, // called from API-GATEWAY
  CREATE_LAB_ELEMENT: { message: 'create-lab-element' }, // called from API-GATEWAY
  
  /* LAB-TEST */
  START_LAB_TEST: { message: 'start-lab-test' }, // called from API-GATEWAY
  STOP_LAB_TEST: { message: 'stop-lab-test' }, // called from API-GATEWAY
  
  /* MARKET */
  REFRESH_MARKET_TREE: { message: 'refresh-market-tree' }, // called by API, SCHEDULER
  GET_MARKET_TREE: { message: 'get-market-tree' }, // called from API-GATEWAY
  GET_AVAILABLE_MARKETS: { message: 'get-available-markets' }, // called from API-GATEWAY
  GET_MARKET_TREE_INSTRUMENTS: { message: 'get-market-tree-instruments' }, // called from CORE
  
  /* SETTINGS */
  GET_APP_SETTINGS: { message: 'get-app-settings' }, // called from ANALYST
  UPDATE_APP_SETTINGS: { message: 'update-app-settings' }, // called from API-GATEWAY
  INITIALIZE_IG_LOGIN: { message: 'initialize-ig-login', env: process.env['ENV'] }, // called from CORE
  GET_STREAMING_SESSION_FROM_IG: { message: 'get-streaming-session-from-ig', env: process.env['ENV'] }, // called from ig-streaming-gateway
  
  /* SNAPSHOT */
  SAVE_NEW_SNAPSHOT: { message: 'save-new-snapshot' }, // called from ANALYST
  GET_SNAPSHOTS: { message: 'get-snapshots' }, // called from ANALYST
  
  /* POSITION */
  CLOSE_POSITION_AT_IG: { message: 'close-position-at-ig' }, // called from BROKER
  CLOSE_ALL_OPEN_POSITIONS: { message: 'close-all-open-positions' }, // called by IG-GATEWAY, CORE
  CREATE_POSITION_AT_IG: { message: 'create-position-at-ig' }, // called from BROKER
  GET_ALL_OPEN_POSITIONS: { message: 'get-all-open-positions' },
  GET_OPEN_POSITION_BY_EPIC: { message: 'get-open-position-by-epic' }, // called from BROKER
  GET_OPEN_POSITIONS_FROM_IG: { message: 'get-open-positions-from-ig', env: process.env['ENV'] }, // called from BROKER
  CORE_HANDLE_REJECTION_ERROR: { message: 'core-handle-rejection-error' }, // called from BROKER
  
  /* TRADE */
  SAVE_NEW_TRADE: { message: 'save-new-trade' }, // called from BROKER
  
  /* MISC */
  GET_ALL_STRATEGY_INFOS: { message: 'get-all-strategy-infos' }, // called from API-GATEWAY
  GET_HISTORICAL_PRICES: { message: 'get-historical-prices' },
}
